"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { CalendarIcon, ClipboardList, HomeIcon, MapIcon, Settings, Users } from "lucide-react";

const routes = [
  {
    href: "/",
    label: "Dashboard",
    icon: HomeIcon,
  },
  {
    href: "/inspections",
    label: "Inspections",
    icon: ClipboardList,
  },
  {
    href: "/calendar",
    label: "Calendar",
    icon: CalendarIcon,
  },
  {
    href: "/map",
    label: "Map",
    icon: MapIcon,
  },
  {
    href: "/team",
    label: "Team",
    icon: Users,
  },
  {
    href: "/settings",
    label: "Settings",
    icon: Settings,
  },
];

export function MainNav() {
  const pathname = usePathname();

  return (
    <nav className="border-b">
      <div className="container mx-auto px-4">
        <div className="flex h-16 items-center space-x-4">
          <Link href="/" className="flex items-center space-x-2">
            <ClipboardList className="h-6 w-6" />
            <span className="font-bold">Inspectly</span>
          </Link>
          <div className="flex-1" />
          <div className="flex items-center space-x-2">
            {routes.map((route) => {
              const Icon = route.icon;
              return (
                <Button
                  key={route.href}
                  variant={pathname === route.href ? "default" : "ghost"}
                  asChild
                >
                  <Link href={route.href} className="flex items-center space-x-2">
                    <Icon className="h-4 w-4" />
                    <span>{route.label}</span>
                  </Link>
                </Button>
              );
            })}
          </div>
        </div>
      </div>
    </nav>
  );
}