"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  DragDropContext,
  Droppable,
  Draggable,
  DropResult,
} from "@hello-pangea/dnd";
import { Loader2, Plus, GripVertical, Trash } from "lucide-react";
import { toast } from "sonner";

type FieldType = "text" | "number" | "select" | "radio" | "checkbox" | "date" | "photo" | "signature" | "location";

interface Field {
  id: string;
  type: FieldType;
  label: string;
  required: boolean;
  options?: string[];
}

interface Section {
  id: string;
  title: string;
  description?: string;
  fields: Field[];
}

const fieldTypes: { value: FieldType; label: string }[] = [
  { value: "text", label: "Text" },
  { value: "number", label: "Number" },
  { value: "select", label: "Dropdown" },
  { value: "radio", label: "Radio Buttons" },
  { value: "checkbox", label: "Checkbox" },
  { value: "date", label: "Date" },
  { value: "photo", label: "Photo Upload" },
  { value: "signature", label: "Signature" },
  { value: "location", label: "Location" },
];

export function TemplateBuilder() {
  const router = useRouter();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [sections, setSections] = useState<Section[]>([
    {
      id: "section-1",
      title: "Section 1",
      fields: [],
    },
  ]);

  const addSection = () => {
    setSections([
      ...sections,
      {
        id: `section-${sections.length + 1}`,
        title: `Section ${sections.length + 1}`,
        fields: [],
      },
    ]);
  };

  const addField = (sectionId: string) => {
    setSections(
      sections.map((section) =>
        section.id === sectionId
          ? {
              ...section,
              fields: [
                ...section.fields,
                {
                  id: `field-${section.fields.length + 1}`,
                  type: "text",
                  label: "New Field",
                  required: false,
                },
              ],
            }
          : section
      )
    );
  };

  const updateField = (
    sectionId: string,
    fieldId: string,
    updates: Partial<Field>
  ) => {
    setSections(
      sections.map((section) =>
        section.id === sectionId
          ? {
              ...section,
              fields: section.fields.map((field) =>
                field.id === fieldId ? { ...field, ...updates } : field
              ),
            }
          : section
      )
    );
  };

  const removeField = (sectionId: string, fieldId: string) => {
    setSections(
      sections.map((section) =>
        section.id === sectionId
          ? {
              ...section,
              fields: section.fields.filter((field) => field.id !== fieldId),
            }
          : section
      )
    );
  };

  const onDragEnd = (result: DropResult) => {
    if (!result.destination) return;

    const sourceSection = sections.find(
      (section) => section.id === result.source.droppableId
    );
    const destSection = sections.find(
      (section) => section.id === result.destination?.droppableId
    );

    if (!sourceSection || !destSection) return;

    const newSections = [...sections];
    const sourceFields = [...sourceSection.fields];
    const destFields = sourceSection === destSection ? sourceFields : [...destSection.fields];
    const [removed] = sourceFields.splice(result.source.index, 1);
    destFields.splice(result.destination.index, 0, removed);

    setSections(
      newSections.map((section) => {
        if (section.id === sourceSection.id) {
          return { ...section, fields: sourceFields };
        }
        if (section.id === destSection.id) {
          return { ...section, fields: destFields };
        }
        return section;
      })
    );
  };

  const handleSubmit = async () => {
    try {
      setIsSubmitting(true);
      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 1000));
      
      toast.success("Template saved successfully");
      router.push("/templates");
    } catch (error) {
      toast.error("Failed to save template");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="grid gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Template Details</CardTitle>
            <CardDescription>
              Enter the basic information for your template.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid gap-4 md:grid-cols-2">
              <div className="space-y-2">
                <label className="text-sm font-medium">Template Name</label>
                <Input placeholder="Enter template name" />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium">Type</label>
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="Select template type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="safety">Safety</SelectItem>
                    <SelectItem value="equipment">Equipment</SelectItem>
                    <SelectItem value="fire">Fire Safety</SelectItem>
                    <SelectItem value="environmental">Environmental</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">Description</label>
              <Textarea placeholder="Enter template description" />
            </div>
          </CardContent>
        </Card>

        <DragDropContext onDragEnd={onDragEnd}>
          {sections.map((section) => (
            <Card key={section.id}>
              <CardHeader>
                <CardTitle>
                  <Input
                    value={section.title}
                    onChange={(e) =>
                      setSections(
                        sections.map((s) =>
                          s.id === section.id
                            ? { ...s, title: e.target.value }
                            : s
                        )
                      )
                    }
                    className="text-lg font-bold"
                  />
                </CardTitle>
                <CardDescription>
                  <Textarea
                    placeholder="Section description (optional)"
                    value={section.description || ""}
                    onChange={(e) =>
                      setSections(
                        sections.map((s) =>
                          s.id === section.id
                            ? { ...s, description: e.target.value }
                            : s
                        )
                      )
                    }
                  />
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <Droppable droppableId={section.id}>
                  {(provided) => (
                    <div
                      {...provided.droppableProps}
                      ref={provided.innerRef}
                      className="space-y-4"
                    >
                      {section.fields.map((field, index) => (
                        <Draggable
                          key={field.id}
                          draggableId={field.id}
                          index={index}
                        >
                          {(provided) => (
                            <div
                              ref={provided.innerRef}
                              {...provided.draggableProps}
                              className="flex items-start space-x-4 rounded-lg border p-4"
                            >
                              <div
                                {...provided.dragHandleProps}
                                className="mt-2"
                              >
                                <GripVertical className="h-5 w-5 text-muted-foreground" />
                              </div>
                              <div className="flex-1 space-y-4">
                                <div className="grid gap-4 md:grid-cols-2">
                                  <Input
                                    value={field.label}
                                    onChange={(e) =>
                                      updateField(section.id, field.id, {
                                        label: e.target.value,
                                      })
                                    }
                                    placeholder="Field label"
                                  />
                                  <Select
                                    value={field.type}
                                    onValueChange={(value) =>
                                      updateField(section.id, field.id, {
                                        type: value as FieldType,
                                      })
                                    }
                                  >
                                    <SelectTrigger>
                                      <SelectValue placeholder="Select field type" />
                                    </SelectTrigger>
                                    <SelectContent>
                                      {fieldTypes.map((type) => (
                                        <SelectItem
                                          key={type.value}
                                          value={type.value}
                                        >
                                          {type.label}
                                        </SelectItem>
                                      ))}
                                    </SelectContent>
                                  </Select>
                                </div>
                                {(field.type === "select" ||
                                  field.type === "radio") && (
                                  <div className="space-y-2">
                                    <label className="text-sm font-medium">
                                      Options (one per line)
                                    </label>
                                    <Textarea
                                      value={field.options?.join("\n") || ""}
                                      onChange={(e) =>
                                        updateField(section.id, field.id, {
                                          options: e.target.value
                                            .split("\n")
                                            .filter(Boolean),
                                        })
                                      }
                                      placeholder="Enter options"
                                    />
                                  </div>
                                )}
                              </div>
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => removeField(section.id, field.id)}
                              >
                                <Trash className="h-4 w-4" />
                              </Button>
                            </div>
                          )}
                        </Draggable>
                      ))}
                      {provided.placeholder}
                    </div>
                  )}
                </Droppable>
                <Button
                  variant="outline"
                  onClick={() => addField(section.id)}
                >
                  <Plus className="mr-2 h-4 w-4" />
                  Add Field
                </Button>
              </CardContent>
            </Card>
          ))}
        </DragDropContext>

        <Button variant="outline" onClick={addSection}>
          <Plus className="mr-2 h-4 w-4" />
          Add Section
        </Button>

        <div className="flex justify-end space-x-4">
          <Button
            variant="outline"
            onClick={() => router.back()}
          >
            Cancel
          </Button>
          <Button
            onClick={handleSubmit}
            disabled={isSubmitting}
          >
            {isSubmitting && (
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            )}
            Save Template
          </Button>
        </div>
      </div>
    </div>
  );
}