import { sql } from "drizzle-orm";
import { text, integer, sqliteTable } from "drizzle-orm/sqlite-core";

export const users = sqliteTable("users", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull().unique(),
  phone: text("phone").notNull(),
  location: text("location").notNull(),
  type: text("type", { enum: ["Internal", "Contractor"] }).notNull(),
  role: text("role", { enum: ["Admin", "User", "Viewer"] }).notNull(),
  notes: text("notes"),
  createdAt: integer("created_at", { mode: "timestamp" })
    .notNull()
    .default(sql`CURRENT_TIMESTAMP`),
});

export const sites = sqliteTable("sites", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  address: text("address").notNull(),
  latitude: text("latitude").notNull(),
  longitude: text("longitude").notNull(),
  createdAt: integer("created_at", { mode: "timestamp" })
    .notNull()
    .default(sql`CURRENT_TIMESTAMP`),
});

export const templates = sqliteTable("templates", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  type: text("type").notNull(),
  sections: text("sections").notNull(), // JSON string
  createdAt: integer("created_at", { mode: "timestamp" })
    .notNull()
    .default(sql`CURRENT_TIMESTAMP`),
});

export const inspections = sqliteTable("inspections", {
  id: text("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description"),
  siteId: text("site_id")
    .notNull()
    .references(() => sites.id),
  inspectorId: text("inspector_id")
    .notNull()
    .references(() => users.id),
  templateId: text("template_id")
    .notNull()
    .references(() => templates.id),
  priority: text("priority", { enum: ["Low", "Medium", "High"] }).notNull(),
  status: text("status", { enum: ["Pending", "In Progress", "Completed"] }).notNull(),
  dueDate: integer("due_date", { mode: "timestamp" }).notNull(),
  completedAt: integer("completed_at", { mode: "timestamp" }),
  results: text("results"), // JSON string
  createdAt: integer("created_at", { mode: "timestamp" })
    .notNull()
    .default(sql`CURRENT_TIMESTAMP`),
});