"use client";

import { useState } from "react";
import FullCalendar from "@fullcalendar/react";
import dayGridPlugin from "@fullcalendar/daygrid";
import timeGridPlugin from "@fullcalendar/timegrid";
import interactionPlugin from "@fullcalendar/interaction";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useRouter } from "next/navigation";

// Mock data - replace with actual data fetching
const inspections = [
  {
    id: "INS-001",
    title: "Annual Safety Inspection",
    start: "2024-03-20",
    priority: "High",
    status: "In Progress",
  },
  {
    id: "INS-002",
    title: "Quarterly Equipment Check",
    start: "2024-03-22",
    priority: "Medium",
    status: "Pending",
  },
  {
    id: "INS-003",
    title: "Monthly Fire Safety",
    start: "2024-03-19",
    priority: "Low",
    status: "Completed",
  },
];

const priorityColors = {
  High: "var(--destructive)",
  Medium: "var(--warning)",
  Low: "var(--secondary)",
};

export default function CalendarPage() {
  const router = useRouter();
  const [currentEvents, setCurrentEvents] = useState(inspections);

  const events = currentEvents.map((inspection) => ({
    id: inspection.id,
    title: inspection.title,
    start: inspection.start,
    backgroundColor: priorityColors[inspection.priority as keyof typeof priorityColors],
    extendedProps: {
      priority: inspection.priority,
      status: inspection.status,
    },
  }));

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="space-y-1">
          <h1 className="text-3xl font-bold">Calendar</h1>
          <p className="text-muted-foreground">
            View and manage scheduled inspections.
          </p>
        </div>
      </div>

      <div className="grid gap-6">
        <Card className="p-6">
          <FullCalendar
            plugins={[dayGridPlugin, timeGridPlugin, interactionPlugin]}
            initialView="dayGridMonth"
            headerToolbar={{
              left: "prev,next today",
              center: "title",
              right: "dayGridMonth,timeGridWeek,timeGridDay",
            }}
            events={events}
            eventClick={(info) => {
              router.push(`/inspections/${info.event.id}`);
            }}
            height="auto"
            eventContent={(eventInfo) => (
              <div className="p-1">
                <div className="font-medium">{eventInfo.event.title}</div>
                <div className="flex gap-1 text-xs">
                  <Badge variant="outline">
                    {eventInfo.event.extendedProps.priority}
                  </Badge>
                  <Badge variant="outline">
                    {eventInfo.event.extendedProps.status}
                  </Badge>
                </div>
              </div>
            )}
          />
        </Card>
      </div>
    </div>
  );
}