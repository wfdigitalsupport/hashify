import { Suspense } from "react";
import { Button } from "@/components/ui/button";
import { Plus } from "lucide-react";
import Link from "next/link";
import { InspectionsList } from "@/components/inspections/inspections-list";
import { InspectionsTableSkeleton } from "@/components/inspections/inspections-list-skeleton";

export default function InspectionsPage() {
  return (
    <div className="flex flex-col space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">Inspections</h1>
        <Button asChild>
          <Link href="/inspections/new">
            <Plus className="mr-2 h-4 w-4" />
            New Inspection
          </Link>
        </Button>
      </div>

      <Suspense fallback={<InspectionsTableSkeleton />}>
        <InspectionsList />
      </Suspense>
    </div>
  );
}