"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuCheckboxItem,
  DropdownMenuContent,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { Filter, CalendarIcon } from "lucide-react";
import { format } from "date-fns";
import { cn } from "@/lib/utils";

interface FilterState {
  status: string[];
  priority: string[];
  frequency: string[];
  dateRange: {
    from: Date | undefined;
    to: Date | undefined;
  };
}

interface InspectionFiltersProps {
  onFilterChange?: (filters: FilterState) => void;
}

export function InspectionFilters({ onFilterChange }: InspectionFiltersProps) {
  const [filters, setFilters] = useState<FilterState>({
    status: ["Pending", "In Progress", "Completed"],
    priority: ["High", "Medium", "Low"],
    frequency: ["Daily", "Weekly", "Monthly", "Quarterly", "Bi-Yearly", "Yearly"],
    dateRange: {
      from: undefined,
      to: undefined,
    },
  });

  const updateFilters = (key: keyof FilterState, value: any) => {
    const newFilters = { ...filters, [key]: value };
    setFilters(newFilters);
    onFilterChange?.(newFilters);
  };

  return (
    <div className="flex items-center space-x-2">
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="outline" size="sm">
            <Filter className="mr-2 h-4 w-4" />
            Status
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end" className="w-[200px]">
          <DropdownMenuLabel>Filter by Status</DropdownMenuLabel>
          <DropdownMenuSeparator />
          {["Pending", "In Progress", "Completed"].map((status) => (
            <DropdownMenuCheckboxItem
              key={status}
              checked={filters.status.includes(status)}
              onCheckedChange={(checked) => {
                const newStatus = checked
                  ? [...filters.status, status]
                  : filters.status.filter((s) => s !== status);
                updateFilters("status", newStatus);
              }}
            >
              {status}
            </DropdownMenuCheckboxItem>
          ))}
        </DropdownMenuContent>
      </DropdownMenu>

      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="outline" size="sm">
            <Filter className="mr-2 h-4 w-4" />
            Priority
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end" className="w-[200px]">
          <DropdownMenuLabel>Filter by Priority</DropdownMenuLabel>
          <DropdownMenuSeparator />
          {["High", "Medium", "Low"].map((priority) => (
            <DropdownMenuCheckboxItem
              key={priority}
              checked={filters.priority.includes(priority)}
              onCheckedChange={(checked) => {
                const newPriority = checked
                  ? [...filters.priority, priority]
                  : filters.priority.filter((p) => p !== priority);
                updateFilters("priority", newPriority);
              }}
            >
              {priority}
            </DropdownMenuCheckboxItem>
          ))}
        </DropdownMenuContent>
      </DropdownMenu>

      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="outline" size="sm">
            <Filter className="mr-2 h-4 w-4" />
            Frequency
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end" className="w-[200px]">
          <DropdownMenuLabel>Filter by Frequency</DropdownMenuLabel>
          <DropdownMenuSeparator />
          {[
            "Daily",
            "Weekly",
            "Monthly",
            "Quarterly",
            "Bi-Yearly",
            "Yearly",
          ].map((frequency) => (
            <DropdownMenuCheckboxItem
              key={frequency}
              checked={filters.frequency.includes(frequency ]}
              onCheckedChange={(checked) => {
                const newFrequency = checked
                  ? [...filters.frequency, frequency]
                  : filters.frequency.filter((f) => f !== frequency);
                updateFilters("frequency", newFrequency);
              }}
            >
              {frequency}
            </DropdownMenuCheckboxItem>
          ))}
        </DropdownMenuContent>
      </DropdownMenu>

      <Popover>
        <PopoverTrigger asChild>
          <Button variant="outline" size="sm">
            <CalendarIcon className="mr-2 h-4 w-4" />
            {filters.dateRange.from ? (
              filters.dateRange.to ? (
                <>
                  {format(filters.dateRange.from, "LLL dd, y")} -{" "}
                  {format(filters.dateRange.to, "LLL dd, y")}
                </>
              ) : (
                format(filters.dateRange.from, "LLL dd, y")
              )
            ) : (
              <span>Date Range</span>
            )}
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-auto p-0" align="end">
          <Calendar
            initialFocus
            mode="range"
            defaultMonth={filters.dateRange.from}
            selected={{
              from: filters.dateRange.from,
              to: filters.dateRange.to,
            }}
            onSelect={(range) => {
              updateFilters("dateRange", {
                from: range?.from,
                to: range?.to,
              });
            }}
            numberOfMonths={2}
          />
        </PopoverContent>
      </Popover>
    </div>
  );
}