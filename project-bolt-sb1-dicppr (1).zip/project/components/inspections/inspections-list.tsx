"use client";

import { useState } from "react";
import Link from "next/link";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { MoreHorizontal, Search } from "lucide-react";
import { InspectionFilters } from "./inspection-filters";

const inspections = [
  {
    id: "INS-001",
    title: "Annual Safety Inspection",
    site: "Main Office",
    inspector: {
      name: "John Doe",
      avatar: "https://i.pravatar.cc/150?u=john",
    },
    priority: "High",
    status: "In Progress",
    dueDate: "2024-03-20",
    type: "Safety",
  },
  {
    id: "INS-002",
    title: "Quarterly Equipment Check",
    site: "Warehouse A",
    inspector: {
      name: "Jane Smith",
      avatar: "https://i.pravatar.cc/150?u=jane",
    },
    priority: "Medium",
    status: "Pending",
    dueDate: "2024-03-22",
    type: "Equipment",
  },
  {
    id: "INS-003",
    title: "Monthly Fire Safety",
    site: "Factory B",
    inspector: {
      name: "Mike Johnson",
      avatar: "https://i.pravatar.cc/150?u=mike",
    },
    priority: "Low",
    status: "Completed",
    dueDate: "2024-03-19",
    type: "Fire Safety",
  },
];

const priorityColors = {
  High: "destructive",
  Medium: "warning",
  Low: "secondary",
} as const;

const statusColors = {
  "In Progress": "warning",
  Pending: "secondary",
  Completed: "success",
} as const;

export function InspectionsList() {
  const [searchQuery, setSearchQuery] = useState("");

  const filteredInspections = inspections.filter((inspection) =>
    inspection.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    inspection.site.toLowerCase().includes(searchQuery.toLowerCase()) ||
    inspection.inspector.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <Search className="h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search inspections..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-[300px]"
          />
        </div>
        <InspectionFilters />
      </div>

      <div className="rounded-md border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>ID</TableHead>
              <TableHead>Title</TableHead>
              <TableHead>Site</TableHead>
              <TableHead>Inspector</TableHead>
              <TableHead>Type</TableHead>
              <TableHead>Priority</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Due Date</TableHead>
              <TableHead className="w-[50px]"></TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredInspections.map((inspection) => (
              <TableRow key={inspection.id}>
                <TableCell className="font-medium">{inspection.id}</TableCell>
                <TableCell>
                  <Link
                    href={`/inspections/${inspection.id}`}
                    className="text-primary hover:underline"
                  >
                    {inspection.title}
                  </Link>
                </TableCell>
                <TableCell>{inspection.site}</TableCell>
                <TableCell>
                  <div className="flex items-center space-x-2">
                    <Avatar className="h-6 w-6">
                      <AvatarImage src={inspection.inspector.avatar} />
                      <AvatarFallback>
                        {inspection.inspector.name
                          .split(" ")
                          .map((n) => n[0])
                          .join("")}
                      </AvatarFallback>
                    </Avatar>
                    <span>{inspection.inspector.name}</span>
                  </div>
                </TableCell>
                <TableCell>{inspection.type}</TableCell>
                <TableCell>
                  <Badge
                    variant={
                      priorityColors[inspection.priority as keyof typeof priorityColors]
                    }
                  >
                    {inspection.priority}
                  </Badge>
                </TableCell>
                <TableCell>
                  <Badge
                    variant={
                      statusColors[inspection.status as keyof typeof statusColors]
                    }
                  >
                    {inspection.status}
                  </Badge>
                </TableCell>
                <TableCell>{inspection.dueDate}</TableCell>
                <TableCell>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button
                        variant="ghost"
                        className="h-8 w-8 p-0"
                      >
                        <MoreHorizontal className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem
                        onClick={() => window.location.href = `/inspections/${inspection.id}`}
                      >
                        View details
                      </DropdownMenuItem>
                      <DropdownMenuItem
                        onClick={() => window.location.href = `/inspections/${inspection.id}/edit`}
                      >
                        Edit
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}