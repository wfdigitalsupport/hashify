"use client";

import { useState } from "react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { MoreHorizontal, Search } from "lucide-react";
import { EditTeamMemberDialog } from "./edit-team-member-dialog";

// Mock data - replace with actual data fetching
const teamMembers = [
  {
    id: "1",
    name: "John Doe",
    email: "john@example.com",
    phone: "+1 (555) 123-4567",
    location: "Main Office",
    type: "Internal",
    role: "Admin",
    avatar: "https://i.pravatar.cc/150?u=john",
    notes: "Senior inspector with 10+ years experience",
  },
  {
    id: "2",
    name: "Jane Smith",
    email: "jane@example.com",
    phone: "+1 (555) 234-5678",
    location: "Warehouse A",
    type: "Internal",
    role: "User",
    avatar: "https://i.pravatar.cc/150?u=jane",
    notes: "Specializes in equipment inspections",
  },
  {
    id: "3",
    name: "Mike Johnson",
    email: "mike@contractor.com",
    phone: "+1 (555) 345-6789",
    location: "Factory B",
    type: "Contractor",
    role: "Viewer",
    avatar: "https://i.pravatar.cc/150?u=mike",
    notes: "Fire safety consultant",
  },
];

const roleColors = {
  Admin: "destructive",
  User: "default",
  Viewer: "secondary",
} as const;

const typeColors = {
  Internal: "default",
  Contractor: "warning",
} as const;

export function TeamList() {
  const [searchQuery, setSearchQuery] = useState("");

  const filteredMembers = teamMembers.filter((member) =>
    member.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    member.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
    member.location.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="space-y-4">
      <div className="flex items-center space-x-2">
        <Search className="h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="Search team members..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="w-[300px]"
        />
      </div>

      <div className="rounded-md border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Name</TableHead>
              <TableHead>Email</TableHead>
              <TableHead>Phone</TableHead>
              <TableHead>Location</TableHead>
              <TableHead>Type</TableHead>
              <TableHead>Role</TableHead>
              <TableHead className="w-[50px]"></TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredMembers.map((member) => (
              <TableRow key={member.id}>
                <TableCell>
                  <div className="flex items-center space-x-2">
                    <Avatar>
                      <AvatarImage src={member.avatar} />
                      <AvatarFallback>
                        {member.name
                          .split(" ")
                          .map((n) => n[0])
                          .join("")}
                      </AvatarFallback>
                    </Avatar>
                    <span className="font-medium">{member.name}</span>
                  </div>
                </TableCell>
                <TableCell>
                  <a
                    href={`mailto:${member.email}`}
                    className="text-primary hover:underline"
                  >
                    {member.email}
                  </a>
                </TableCell>
                <TableCell>
                  <a
                    href={`tel:${member.phone}`}
                    className="text-primary hover:underline"
                  >
                    {member.phone}
                  </a>
                </TableCell>
                <TableCell>{member.location}</TableCell>
                <TableCell>
                  <Badge variant={typeColors[member.type as keyof typeof typeColors]}>
                    {member.type}
                  </Badge>
                </TableCell>
                <TableCell>
                  <Badge variant={roleColors[member.role as keyof typeof roleColors]}>
                    {member.role}
                  </Badge>
                </TableCell>
                <TableCell>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button
                        variant="ghost"
                        className="h-8 w-8 p-0"
                      >
                        <MoreHorizontal className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <EditTeamMemberDialog member={member}>
                        <DropdownMenuItem onSelect={(e) => e.preventDefault()}>
                          Edit member
                        </DropdownMenuItem>
                      </EditTeamMemberDialog>
                      <DropdownMenuItem className="text-destructive">
                        Remove member
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}