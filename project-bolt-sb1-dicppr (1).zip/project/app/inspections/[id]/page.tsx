import { notFound } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Calendar, MapPin, User } from "lucide-react";
import Link from "next/link";

// Mock data - replace with actual data fetching
const getInspection = (id: string) => {
  const inspection = {
    id: "INS-001",
    title: "Annual Safety Inspection",
    description: "Comprehensive safety inspection of all facilities and equipment",
    site: "Main Office",
    address: "123 Business Ave, Suite 100, Business City, BC 12345",
    inspector: {
      name: "John Doe",
      avatar: "https://i.pravatar.cc/150?u=john",
    },
    priority: "High",
    status: "In Progress",
    dueDate: "2024-03-20",
    type: "Safety",
    tasks: [
      { id: 1, title: "Check fire extinguishers", completed: true },
      { id: 2, title: "Inspect emergency exits", completed: true },
      { id: 3, title: "Test alarm systems", completed: false },
      { id: 4, title: "Review safety protocols", completed: false },
    ],
  };

  if (id !== inspection.id) {
    return null;
  }

  return inspection;
};

export default function InspectionPage({
  params,
}: {
  params: { id: string };
}) {
  const inspection = getInspection(params.id);

  if (!inspection) {
    notFound();
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="space-y-1">
          <h1 className="text-3xl font-bold">{inspection.title}</h1>
          <p className="text-muted-foreground">{inspection.description}</p>
        </div>
        <div className="flex items-center space-x-2">
          <Button variant="outline" asChild>
            <Link href={`/inspections/${inspection.id}/edit`}>
              Edit Inspection
            </Link>
          </Button>
          <Button>Complete Inspection</Button>
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Details</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center space-x-2">
              <MapPin className="h-4 w-4 text-muted-foreground" />
              <div>
                <div className="font-medium">{inspection.site}</div>
                <div className="text-sm text-muted-foreground">
                  {inspection.address}
                </div>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <User className="h-4 w-4 text-muted-foreground" />
              <div className="flex items-center space-x-2">
                <Avatar className="h-8 w-8">
                  <AvatarImage src={inspection.inspector.avatar} />
                  <AvatarFallback>
                    {inspection.inspector.name
                      .split(" ")
                      .map((n) => n[0])
                      .join("")}
                  </AvatarFallback>
                </Avatar>
                <span className="font-medium">{inspection.inspector.name}</span>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <Calendar className="h-4 w-4 text-muted-foreground" />
              <div className="font-medium">{inspection.dueDate}</div>
            </div>
            <div className="flex items-center space-x-2">
              <Badge variant="outline">{inspection.type}</Badge>
              <Badge
                variant={
                  inspection.priority === "High"
                    ? "destructive"
                    : inspection.priority === "Medium"
                    ? "warning"
                    : "secondary"
                }
              >
                {inspection.priority}
              </Badge>
              <Badge
                variant={
                  inspection.status === "Completed"
                    ? "success"
                    : inspection.status === "In Progress"
                    ? "warning"
                    : "secondary"
                }
              >
                {inspection.status}
              </Badge>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Tasks</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {inspection.tasks.map((task) => (
                <div
                  key={task.id}
                  className="flex items-center space-x-2"
                >
                  <input
                    type="checkbox"
                    checked={task.completed}
                    className="h-4 w-4 rounded border-gray-300"
                    readOnly
                  />
                  <span
                    className={
                      task.completed ? "text-muted-foreground line-through" : ""
                    }
                  >
                    {task.title}
                  </span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}