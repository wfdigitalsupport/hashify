"use client";

import { useState } from "react";
import { GoogleMap, LoadScript, Marker, InfoWindow } from "@react-google-maps/api";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import Link from "next/link";

// Mock data - replace with actual data fetching
const locations = [
  {
    id: "INS-001",
    title: "Annual Safety Inspection",
    site: "Main Office",
    address: "123 Business Ave",
    position: { lat: 40.7128, lng: -74.0060 },
    inspector: "John Doe",
    priority: "High",
    status: "In Progress",
    dueDate: "2024-03-20",
  },
  {
    id: "INS-002",
    title: "Quarterly Equipment Check",
    site: "Warehouse A",
    address: "456 Industrial Pkwy",
    position: { lat: 40.7282, lng: -73.9942 },
    inspector: "Jane Smith",
    priority: "Medium",
    status: "Pending",
    dueDate: "2024-03-22",
  },
  {
    id: "INS-003",
    title: "Monthly Fire Safety",
    site: "Factory B",
    address: "789 Manufacturing Rd",
    position: { lat: 40.7112, lng: -74.0123 },
    inspector: "Mike Johnson",
    priority: "Low",
    status: "Completed",
    dueDate: "2024-03-19",
  },
];

const priorityColors = {
  High: "destructive",
  Medium: "warning",
  Low: "secondary",
} as const;

const statusColors = {
  "In Progress": "warning",
  Pending: "secondary",
  Completed: "success",
} as const;

const mapContainerStyle = {
  width: "100%",
  height: "70vh",
};

const center = {
  lat: 40.7128,
  lng: -74.0060,
};

export default function MapPage() {
  const [selectedLocation, setSelectedLocation] = useState<typeof locations[0] | null>(null);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="space-y-1">
          <h1 className="text-3xl font-bold">Map</h1>
          <p className="text-muted-foreground">
            View inspection locations and team member positions.
          </p>
        </div>
      </div>

      <Card className="p-6">
        <LoadScript googleMapsApiKey="YOUR_GOOGLE_MAPS_API_KEY">
          <GoogleMap
            mapContainerStyle={mapContainerStyle}
            center={center}
            zoom={13}
          >
            {locations.map((location) => (
              <Marker
                key={location.id}
                position={location.position}
                onClick={() => setSelectedLocation(location)}
              />
            ))}

            {selectedLocation && (
              <InfoWindow
                position={selectedLocation.position}
                onCloseClick={() => setSelectedLocation(null)}
              >
                <div className="p-2 max-w-sm">
                  <h3 className="font-semibold mb-2">
                    <Link
                      href={`/inspections/${selectedLocation.id}`}
                      className="text-primary hover:underline"
                    >
                      {selectedLocation.title}
                    </Link>
                  </h3>
                  <div className="space-y-2 text-sm">
                    <p>
                      <strong>Site:</strong> {selectedLocation.site}
                    </p>
                    <p>
                      <strong>Address:</strong> {selectedLocation.address}
                    </p>
                    <p>
                      <strong>Inspector:</strong> {selectedLocation.inspector}
                    </p>
                    <p>
                      <strong>Due Date:</strong> {selectedLocation.dueDate}
                    </p>
                    <div className="flex gap-2">
                      <Badge
                        variant={
                          priorityColors[
                            selectedLocation.priority as keyof typeof priorityColors
                          ]
                        }
                      >
                        {selectedLocation.priority}
                      </Badge>
                      <Badge
                        variant={
                          statusColors[
                            selectedLocation.status as keyof typeof statusColors
                          ]
                        }
                      >
                        {selectedLocation.status}
                      </Badge>
                    </div>
                  </div>
                </div>
              </InfoWindow>
            )}
          </GoogleMap>
        </LoadScript>
      </Card>
    </div>
  );
}