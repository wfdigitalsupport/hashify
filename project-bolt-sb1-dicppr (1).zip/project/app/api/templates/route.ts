import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { templates } from '@/lib/db/schema';

export async function GET() {
  try {
    const allTemplates = await db.select().from(templates);
    return NextResponse.json(allTemplates);
  } catch (error) {
    console.error('Error fetching templates:', error);
    return NextResponse.json({ error: 'Failed to fetch templates' }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { name, type, description, sections } = body;

    const result = await db.insert(templates).values({
      id: `tpl_${Date.now()}`,
      name,
      type,
      description,
      sections: JSON.stringify(sections),
    });

    return NextResponse.json(result);
  } catch (error) {
    console.error('Error creating template:', error);
    return NextResponse.json({ error: 'Failed to create template' }, { status: 500 });
  }
}