import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { inspections, sites, users, templates } from '@/lib/db/schema';
import { eq, and, like, gte, lte } from 'drizzle-orm';

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    
    // Get filter parameters
    const search = searchParams.get('search');
    const status = searchParams.get('status');
    const priority = searchParams.get('priority');
    const startDate = searchParams.get('startDate');
    const endDate = searchParams.get('endDate');
    const frequency = searchParams.get('frequency');

    let query = db.select().from(inspections)
      .leftJoin(sites, eq(inspections.siteId, sites.id))
      .leftJoin(users, eq(inspections.inspectorId, users.id))
      .leftJoin(templates, eq(inspections.templateId, templates.id));

    // Apply filters
    if (search) {
      query = query.where(like(inspections.title, `%${search}%`));
    }
    if (status) {
      query = query.where(eq(inspections.status, status));
    }
    if (priority) {
      query = query.where(eq(inspections.priority, priority));
    }
    if (startDate) {
      query = query.where(gte(inspections.dueDate, new Date(startDate).getTime()));
    }
    if (endDate) {
      query = query.where(lte(inspections.dueDate, new Date(endDate).getTime()));
    }
    if (frequency) {
      query = query.where(eq(inspections.frequency, frequency));
    }

    const results = await query;
    return NextResponse.json(results);
  } catch (error) {
    console.error('Error fetching inspections:', error);
    return NextResponse.json({ error: 'Failed to fetch inspections' }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const {
      title,
      description,
      siteId,
      inspectorId,
      templateId,
      priority,
      frequency,
      customFrequency,
      startDate,
      dueDate,
    } = body;

    const result = await db.insert(inspections).values({
      id: `ins_${Date.now()}`,
      title,
      description,
      siteId,
      inspectorId,
      templateId,
      priority,
      status: 'Pending',
      frequency,
      customFrequency: customFrequency ? JSON.stringify(customFrequency) : null,
      startDate: new Date(startDate).getTime(),
      dueDate: new Date(dueDate).getTime(),
    });

    return NextResponse.json(result);
  } catch (error) {
    console.error('Error creating inspection:', error);
    return NextResponse.json({ error: 'Failed to create inspection' }, { status: 500 });
  }
}