import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { inspections } from '@/lib/db/schema';
import { eq } from 'drizzle-orm';

export async function GET(
  request: Request,
  { params }: { params: { id: string } }
) {
  try {
    const inspection = await db
      .select()
      .from(inspections)
      .where(eq(inspections.id, params.id));

    if (!inspection.length) {
      return NextResponse.json({ error: 'Inspection not found' }, { status: 404 });
    }

    return NextResponse.json(inspection[0]);
  } catch (error) {
    console.error('Error fetching inspection:', error);
    return NextResponse.json({ error: 'Failed to fetch inspection' }, { status: 500 });
  }
}

export async function PUT(
  request: Request,
  { params }: { params: { id: string } }
) {
  try {
    const body = await request.json();
    const {
      title,
      description,
      siteId,
      inspectorId,
      templateId,
      priority,
      status,
      frequency,
      customFrequency,
      startDate,
      dueDate,
      results,
    } = body;

    const result = await db
      .update(inspections)
      .set({
        title,
        description,
        siteId,
        inspectorId,
        templateId,
        priority,
        status,
        frequency,
        customFrequency: customFrequency ? JSON.stringify(customFrequency) : null,
        startDate: new Date(startDate).getTime(),
        dueDate: new Date(dueDate).getTime(),
        results: results ? JSON.stringify(results) : null,
        completedAt: status === 'Completed' ? Date.now() : null,
      })
      .where(eq(inspections.id, params.id));

    return NextResponse.json(result);
  } catch (error) {
    console.error('Error updating inspection:', error);
    return NextResponse.json({ error: 'Failed to update inspection' }, { status: 500 });
  }
}

export async function DELETE(
  request: Request,
  { params }: { params: { id: string } }
) {
  try {
    await db.delete(inspections).where(eq(inspections.id, params.id));
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Error deleting inspection:', error);
    return NextResponse.json({ error: 'Failed to delete inspection' }, { status: 500 });
  }
}