const { db } = require("../lib/db");
const { users, sites, templates, inspections } = require("../lib/db/schema");

// Seed Users
const seedUsers = [
  {
    id: "usr_1",
    name: "John Doe",
    email: "john@example.com",
    phone: "+1 (555) 123-4567",
    location: "Main Office",
    type: "Internal",
    role: "Admin",
    notes: "Senior inspector with 10+ years experience",
  },
  {
    id: "usr_2",
    name: "Jane Smith",
    email: "jane@example.com",
    phone: "+1 (555) 234-5678",
    location: "Warehouse A",
    type: "Internal",
    role: "User",
    notes: "Specializes in equipment inspections",
  },
  {
    id: "usr_3",
    name: "Mike Johnson",
    email: "mike@contractor.com",
    phone: "+1 (555) 345-6789",
    location: "Factory B",
    type: "Contractor",
    role: "Viewer",
    notes: "Fire safety consultant",
  },
];

// Seed Sites
const seedSites = [
  {
    id: "site_1",
    name: "Main Office",
    address: "123 Business Ave, Suite 100",
    latitude: "40.7128",
    longitude: "-74.0060",
  },
  {
    id: "site_2",
    name: "Warehouse A",
    address: "456 Industrial Pkwy",
    latitude: "40.7282",
    longitude: "-73.9942",
  },
  {
    id: "site_3",
    name: "Factory B",
    address: "789 Manufacturing Rd",
    latitude: "40.7112",
    longitude: "-74.0123",
  },
];

// Seed Templates
const seedTemplates = [
  {
    id: "tpl_1",
    name: "Safety Inspection",
    description: "Standard safety inspection template",
    type: "Safety",
    sections: JSON.stringify([
      {
        title: "General Safety",
        fields: [
          { type: "checkbox", label: "Emergency exits clear", required: true },
          { type: "checkbox", label: "Fire extinguishers accessible", required: true },
        ],
      },
    ]),
  },
  {
    id: "tpl_2",
    name: "Equipment Check",
    description: "Machinery and equipment inspection",
    type: "Equipment",
    sections: JSON.stringify([
      {
        title: "Equipment Status",
        fields: [
          { type: "checkbox", label: "Machine guards in place", required: true },
          { type: "text", label: "Maintenance notes", required: false },
        ],
      },
    ]),
  },
];

// Seed Inspections
const seedInspections = [
  {
    id: "ins_1",
    title: "Annual Safety Inspection",
    description: "Comprehensive safety inspection of all facilities",
    siteId: "site_1",
    inspectorId: "usr_1",
    templateId: "tpl_1",
    priority: "High",
    status: "In Progress",
    dueDate: new Date("2024-03-20").getTime(),
    results: null,
  },
  {
    id: "ins_2",
    title: "Quarterly Equipment Check",
    description: "Regular equipment maintenance inspection",
    siteId: "site_2",
    inspectorId: "usr_2",
    templateId: "tpl_2",
    priority: "Medium",
    status: "Pending",
    dueDate: new Date("2024-03-22").getTime(),
    results: null,
  },
];

async function seed() {
  try {
      console.log("🌱 Seeding database...");

  // Clear existing data
  db.delete(inspections).run();
  db.delete(templates).run();
  db.delete(sites).run();
  db.delete(users).run();

  // Insert new data
  db.insert(users).values(seedUsers).run();
  db.insert(sites).values(seedSites).run();
  db.insert(templates).values(seedTemplates).run();
  db.insert(inspections).values(seedInspections).run();
    console.log("Seeding completed successfully");
  } catch (error) {
    console.error("Error seeding database:", error);
    process.exit(1);
  }
}

seed().catch(console.error);