"use client";

import { useState } from "react";
import Link from "next/link";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { MoreHorizontal, Search } from "lucide-react";

// Mock data - replace with actual data fetching
const templates = [
  {
    id: "TPL-001",
    name: "Safety Inspection",
    description: "Standard safety inspection template",
    type: "Safety",
    sections: 4,
    questions: 15,
    lastUpdated: "2024-03-15",
  },
  {
    id: "TPL-002",
    name: "Equipment Check",
    description: "Machinery and equipment inspection",
    type: "Equipment",
    sections: 3,
    questions: 12,
    lastUpdated: "2024-03-14",
  },
  {
    id: "TPL-003",
    name: "Fire Safety Audit",
    description: "Fire safety compliance check",
    type: "Fire Safety",
    sections: 5,
    questions: 20,
    lastUpdated: "2024-03-13",
  },
];

export function TemplatesList() {
  const [searchQuery, setSearchQuery] = useState("");

  const filteredTemplates = templates.filter((template) =>
    template.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    template.description.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="space-y-4">
      <div className="flex items-center space-x-2">
        <Search className="h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="Search templates..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="w-[300px]"
        />
      </div>

      <div className="rounded-md border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Name</TableHead>
              <TableHead>Description</TableHead>
              <TableHead>Type</TableHead>
              <TableHead>Sections</TableHead>
              <TableHead>Questions</TableHead>
              <TableHead>Last Updated</TableHead>
              <TableHead className="w-[50px]"></TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredTemplates.map((template) => (
              <TableRow key={template.id}>
                <TableCell>
                  <Link
                    href={`/templates/${template.id}`}
                    className="font-medium text-primary hover:underline"
                  >
                    {template.name}
                  </Link>
                </TableCell>
                <TableCell>{template.description}</TableCell>
                <TableCell>
                  <Badge variant="outline">{template.type}</Badge>
                </TableCell>
                <TableCell>{template.sections}</TableCell>
                <TableCell>{template.questions}</TableCell>
                <TableCell>{template.lastUpdated}</TableCell>
                <TableCell>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button
                        variant="ghost"
                        className="h-8 w-8 p-0"
                      >
                        <MoreHorizontal className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem
                        onClick={() => window.location.href = `/templates/${template.id}`}
                      >
                        View details
                      </DropdownMenuItem>
                      <DropdownMenuItem
                        onClick={() => window.location.href = `/templates/${template.id}/edit`}
                      >
                        Edit
                      </DropdownMenuItem>
                      <DropdownMenuItem
                        onClick={() => window.location.href = `/templates/${template.id}/duplicate`}
                      >
                        Duplicate
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}