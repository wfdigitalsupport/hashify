"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import * as z from "zod";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { toast } from "sonner";

const integrationSettingsSchema = z.object({
  googleMapsApiKey: z.string().min(1, "API key is required"),
  enableGoogleMaps: z.boolean(),
  enableCalendarSync: z.boolean(),
  calendarSyncEmail: z.string().email().optional(),
});

type IntegrationSettingsValues = z.infer<typeof integrationSettingsSchema>;

const defaultValues: Partial<IntegrationSettingsValues> = {
  googleMapsApiKey: process.env.NEXT_PUBLIC_GOOGLE_MAPS_API_KEY || "",
  enableGoogleMaps: true,
  enableCalendarSync: false,
};

export function IntegrationSettings() {
  const form = useForm<IntegrationSettingsValues>({
    resolver: zodResolver(integrationSettingsSchema),
    defaultValues,
  });

  async function onSubmit(data: IntegrationSettingsValues) {
    try {
      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 1000));
      toast.success("Integration settings saved successfully");
    } catch (error) {
      toast.error("Failed to save integration settings");
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Integration Settings</CardTitle>
        <CardDescription>
          Configure third-party service integrations.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <div className="space-y-4">
              <FormField
                control={form.control}
                name="enableGoogleMaps"
                render={({ field }) => (
                  <FormItem className="flex items-center justify-between rounded-lg border p-4">
                    <div className="space-y-0.5">
                      <FormLabel className="text-base">Google Maps</FormLabel>
                      <FormDescription>
                        Enable Google Maps integration for location tracking
                      </FormDescription>
                    </div>
                    <FormControl>
                      <Switch
                        checked={field.value}
                        onCheckedChange={field.onChange}
                      />
                    </FormControl>
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="googleMapsApiKey"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Google Maps API Key</FormLabel>
                    <FormControl>
                      <Input {...field} type="password" />
                    </FormControl>
                    <FormDescription>
                      Enter your Google Maps API key for location services
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="enableCalendarSync"
                render={({ field }) => (
                  <FormItem className="flex items-center justify-between rounded-lg border p-4">
                    <div className="space-y-0.5">
                      <FormLabel className="text-base">Calendar Sync</FormLabel>
                      <FormDescription>
                        Sync inspections with your calendar
                      </FormDescription>
                    </div>
                    <FormControl>
                      <Switch
                        checked={field.value}
                        onCheckedChange={field.onChange}
                      />
                    </FormControl>
                  </FormItem>
                )}
              />

              {form.watch("enableCalendarSync") && (
                <FormField
                  control={form.control}
                  name="calendarSyncEmail"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Calendar Email</FormLabel>
                      <FormControl>
                        <Input
                          type="email"
                          placeholder="Enter calendar email"
                          {...field}
                        />
                      </FormControl>
                      <FormDescription>
                        Email address for calendar synchronization
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              )}
            </div>

            <div className="flex justify-end">
              <Button type="submit">Save Integration Settings</Button>
            </div>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}