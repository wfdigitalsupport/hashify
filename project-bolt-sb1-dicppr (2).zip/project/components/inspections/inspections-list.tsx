"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { MoreHorizontal, Search } from "lucide-react";
import { InspectionFilters } from "./inspection-filters";
import { toast } from "sonner";

interface Inspector {
  id: string;
  name: string;
  avatar?: string;
}

interface Site {
  id: string;
  name: string;
}

interface Inspection {
  id: string;
  title: string;
  siteId: string;
  site?: Site;
  inspectorId: string;
  inspector?: Inspector;
  priority: "High" | "Medium" | "Low";
  status: "Pending" | "In Progress" | "Completed";
  dueDate: number;
  type: string;
}

const priorityColors = {
  High: "destructive",
  Medium: "warning",
  Low: "secondary",
} as const;

const statusColors = {
  "In Progress": "warning",
  Pending: "secondary",
  Completed: "success",
} as const;

export function InspectionsList() {
  const [searchQuery, setSearchQuery] = useState("");
  const [inspections, setInspections] = useState<Inspection[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchInspections();
  }, []);

  const fetchInspections = async () => {
    try {
      const response = await fetch('/api/inspections');
      if (!response.ok) throw new Error('Failed to fetch inspections');
      const data = await response.json();
      setInspections(data);
    } catch (error) {
      console.error('Error fetching inspections:', error);
      toast.error('Failed to load inspections');
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id: string) => {
    try {
      const response = await fetch(`/api/inspections/${id}`, {
        method: 'DELETE',
      });

      if (!response.ok) throw new Error('Failed to delete inspection');
      
      toast.success('Inspection deleted successfully');
      fetchInspections(); // Refresh the list
    } catch (error) {
      console.error('Error deleting inspection:', error);
      toast.error('Failed to delete inspection');
    }
  };

  const filteredInspections = inspections.filter((inspection) =>
    inspection.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    inspection.site?.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    inspection.inspector?.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleFilterChange = async (filters: any) => {
    try {
      const queryParams = new URLSearchParams();
      
      if (filters.status.length) {
        queryParams.append('status', filters.status.join(','));
      }
      if (filters.priority.length) {
        queryParams.append('priority', filters.priority.join(','));
      }
      if (filters.frequency.length) {
        queryParams.append('frequency', filters.frequency.join(','));
      }
      if (filters.dateRange.from) {
        queryParams.append('startDate', filters.dateRange.from.toISOString());
      }
      if (filters.dateRange.to) {
        queryParams.append('endDate', filters.dateRange.to.toISOString());
      }

      const response = await fetch(`/api/inspections?${queryParams}`);
      if (!response.ok) throw new Error('Failed to fetch filtered inspections');
      
      const data = await response.json();
      setInspections(data);
    } catch (error) {
      console.error('Error applying filters:', error);
      toast.error('Failed to apply filters');
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <Search className="h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search inspections..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-[300px]"
          />
        </div>
        <InspectionFilters onFilterChange={handleFilterChange} />
      </div>

      <div className="rounded-md border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>ID</TableHead>
              <TableHead>Title</TableHead>
              <TableHead>Site</TableHead>
              <TableHead>Inspector</TableHead>
              <TableHead>Type</TableHead>
              <TableHead>Priority</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Due Date</TableHead>
              <TableHead className="w-[50px]"></TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredInspections.map((inspection) => (
              <TableRow key={inspection.id}>
                <TableCell className="font-medium">{inspection.id}</TableCell>
                <TableCell>
                  <Link
                    href={`/inspections/${inspection.id}`}
                    className="text-primary hover:underline"
                  >
                    {inspection.title}
                  </Link>
                </TableCell>
                <TableCell>{inspection.site?.name}</TableCell>
                <TableCell>
                  <div className="flex items-center space-x-2">
                    <Avatar className="h-6 w-6">
                      <AvatarImage src={inspection.inspector?.avatar} />
                      <AvatarFallback>
                        {inspection.inspector?.name
                          .split(" ")
                          .map((n) => n[0])
                          .join("")}
                      </AvatarFallback>
                    </Avatar>
                    <span>{inspection.inspector?.name}</span>
                  </div>
                </TableCell>
                <TableCell>{inspection.type}</TableCell>
                <TableCell>
                  <Badge
                    variant={
                      priorityColors[inspection.priority]
                    }
                  >
                    {inspection.priority}
                  </Badge>
                </TableCell>
                <TableCell>
                  <Badge
                    variant={
                      statusColors[inspection.status]
                    }
                  >
                    {inspection.status}
                  </Badge>
                </TableCell>
                <TableCell>{new Date(inspection.dueDate).toLocaleDateString()}</TableCell>
                <TableCell>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button
                        variant="ghost"
                        className="h-8 w-8 p-0"
                      >
                        <MoreHorizontal className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem asChild>
                        <Link href={`/inspections/${inspection.id}`}>
                          View details
                        </Link>
                      </DropdownMenuItem>
                      <DropdownMenuItem asChild>
                        <Link href={`/inspections/${inspection.id}/edit`}>
                          Edit
                        </Link>
                      </DropdownMenuItem>
                      <DropdownMenuItem
                        className="text-destructive"
                        onClick={() => handleDelete(inspection.id)}
                      >
                        Delete
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}