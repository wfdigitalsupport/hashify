"use client";

import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

const recentInspections = [
  {
    id: "INS-001",
    site: "Main Office",
    inspector: {
      name: "John Doe",
      avatar: "https://i.pravatar.cc/150?u=john",
    },
    priority: "High",
    status: "In Progress",
    dueDate: "2024-03-20",
  },
  {
    id: "INS-002",
    site: "Warehouse A",
    inspector: {
      name: "Jane Smith",
      avatar: "https://i.pravatar.cc/150?u=jane",
    },
    priority: "Medium",
    status: "Pending",
    dueDate: "2024-03-22",
  },
  {
    id: "INS-003",
    site: "Factory B",
    inspector: {
      name: "Mike Johnson",
      avatar: "https://i.pravatar.cc/150?u=mike",
    },
    priority: "Low",
    status: "Completed",
    dueDate: "2024-03-19",
  },
];

const priorityColors = {
  High: "destructive",
  Medium: "warning",
  Low: "secondary",
} as const;

const statusColors = {
  "In Progress": "warning",
  Pending: "secondary",
  Completed: "success",
} as const;

export function RecentInspections() {
  return (
    <Table>
      <TableHeader>
        <TableRow>
          <TableHead>ID</TableHead>
          <TableHead>Site</TableHead>
          <TableHead>Inspector</TableHead>
          <TableHead>Priority</TableHead>
          <TableHead>Status</TableHead>
          <TableHead>Due Date</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {recentInspections.map((inspection) => (
          <TableRow key={inspection.id}>
            <TableCell className="font-medium">{inspection.id}</TableCell>
            <TableCell>{inspection.site}</TableCell>
            <TableCell>
              <div className="flex items-center space-x-2">
                <Avatar className="h-6 w-6">
                  <AvatarImage src={inspection.inspector.avatar} />
                  <AvatarFallback>
                    {inspection.inspector.name
                      .split(" ")
                      .map((n) => n[0])
                      .join("")}
                  </AvatarFallback>
                </Avatar>
                <span>{inspection.inspector.name}</span>
              </div>
            </TableCell>
            <TableCell>
              <Badge variant={priorityColors[inspection.priority as keyof typeof priorityColors]}>
                {inspection.priority}
              </Badge>
            </TableCell>
            <TableCell>
              <Badge variant={statusColors[inspection.status as keyof typeof statusColors]}>
                {inspection.status}
              </Badge>
            </TableCell>
            <TableCell>{inspection.dueDate}</TableCell>
          </TableRow>
        ))}
      </TableBody>
    </Table>
  );
}