import { Suspense } from "react";
import { Button } from "@/components/ui/button";
import { Plus } from "lucide-react";
import { TeamList } from "@/components/team/team-list";
import { TeamListSkeleton } from "@/components/team/team-list-skeleton";
import { AddTeamMemberDialog } from "@/components/team/add-team-member-dialog";

export default function TeamPage() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="space-y-1">
          <h1 className="text-3xl font-bold">Team</h1>
          <p className="text-muted-foreground">
            Manage team members and their permissions.
          </p>
        </div>
        <AddTeamMemberDialog>
          <Button>
            <Plus className="mr-2 h-4 w-4" />
            Add Team Member
          </Button>
        </AddTeamMemberDialog>
      </div>

      <Suspense fallback={<TeamListSkeleton />}>
        <TeamList />
      </Suspense>
    </div>
  );
}