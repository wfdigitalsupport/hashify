"use client";

import { useState, useEffect } from "react";
import FullCalendar from "@fullcalendar/react";
import dayGridPlugin from "@fullcalendar/daygrid";
import timeGridPlugin from "@fullcalendar/timegrid";
import interactionPlugin from "@fullcalendar/interaction";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useRouter } from "next/navigation";
import { Loader2 } from "lucide-react";
import { toast } from "sonner";

interface Inspection {
  id: string;
  title: string;
  startDate: number;
  dueDate: number;
  priority: "High" | "Medium" | "Low";
  status: "Pending" | "In Progress" | "Completed";
}

const priorityColors = {
  High: "var(--destructive)",
  Medium: "var(--warning)",
  Low: "var(--secondary)",
} as const;

export default function CalendarPage() {
  const router = useRouter();
  const [loading, setLoading] = useState(true);
  const [inspections, setInspections] = useState<Inspection[]>([]);

  useEffect(() => {
    fetchInspections();
  }, []);

  const fetchInspections = async () => {
    try {
      const response = await fetch('/api/inspections');
      if (!response.ok) throw new Error('Failed to fetch inspections');
      const data = await response.json();
      setInspections(data);
    } catch (error) {
      console.error('Error fetching inspections:', error);
      toast.error('Failed to load inspections');
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  const events = inspections.map((inspection) => ({
    id: inspection.id,
    title: inspection.title,
    start: new Date(inspection.startDate).toISOString(),
    end: new Date(inspection.dueDate).toISOString(),
    backgroundColor: priorityColors[inspection.priority],
    extendedProps: {
      priority: inspection.priority,
      status: inspection.status,
    },
  }));

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="space-y-1">
          <h1 className="text-3xl font-bold">Calendar</h1>
          <p className="text-muted-foreground">
            View and manage scheduled inspections.
          </p>
        </div>
      </div>

      <div className="grid gap-6">
        <Card className="p-6">
          <FullCalendar
            plugins={[dayGridPlugin, timeGridPlugin, interactionPlugin]}
            initialView="dayGridMonth"
            headerToolbar={{
              left: "prev,next today",
              center: "title",
              right: "dayGridMonth,timeGridWeek,timeGridDay",
            }}
            events={events}
            eventClick={(info) => {
              router.push(`/inspections/${info.event.id}`);
            }}
            height="auto"
            eventContent={(eventInfo) => (
              <div className="p-1">
                <div className="font-medium">{eventInfo.event.title}</div>
                <div className="flex gap-1 text-xs">
                  <Badge variant="outline">
                    {eventInfo.event.extendedProps.priority}
                  </Badge>
                  <Badge variant="outline">
                    {eventInfo.event.extendedProps.status}
                  </Badge>
                </div>
              </div>
            )}
          />
        </Card>
      </div>
    </div>
  );
}