import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { inspections, sites, users, templates } from '@/lib/db/schema';
import { eq, and, like, gte, lte, inArray } from 'drizzle-orm';

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    
    // Get filter parameters
    const search = searchParams.get('search');
    const status = searchParams.get('status')?.split(',');
    const priority = searchParams.get('priority')?.split(',');
    const startDate = searchParams.get('startDate');
    const endDate = searchParams.get('endDate');
    const frequency = searchParams.get('frequency')?.split(',');

    let query = db.select({
      inspections: inspections,
      site: sites,
      inspector: users,
      template: templates,
    })
    .from(inspections)
    .leftJoin(sites, eq(inspections.siteId, sites.id))
    .leftJoin(users, eq(inspections.inspectorId, users.id))
    .leftJoin(templates, eq(inspections.templateId, templates.id));

    // Apply filters
    const conditions = [];

    if (search) {
      conditions.push(like(inspections.title, `%${search}%`));
    }
    if (status?.length) {
      conditions.push(inArray(inspections.status, status));
    }
    if (priority?.length) {
      conditions.push(inArray(inspections.priority, priority));
    }
    if (startDate) {
      conditions.push(gte(inspections.startDate, new Date(startDate).getTime()));
    }
    if (endDate) {
      conditions.push(lte(inspections.dueDate, new Date(endDate).getTime()));
    }
    if (frequency?.length) {
      conditions.push(inArray(inspections.frequency, frequency));
    }

    if (conditions.length > 0) {
      query = query.where(and(...conditions));
    }

    const results = await query;

    // Transform results to include nested objects
    const transformedResults = results.map(({ inspections, site, inspector, template }) => ({
      ...inspections,
      site,
      inspector,
      template,
    }));

    return NextResponse.json(transformedResults);
  } catch (error) {
    console.error('Error fetching inspections:', error);
    return NextResponse.json({ error: 'Failed to fetch inspections' }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const {
      title,
      description,
      siteId,
      inspectorId,
      templateId,
      priority,
      frequency,
      customFrequency,
      startDate,
      dueDate,
      contactName,
      contactEmail,
      contactPhone,
    } = body;

    const result = await db.insert(inspections).values({
      id: `ins_${Date.now()}`,
      title,
      description,
      siteId,
      inspectorId,
      templateId,
      priority,
      status: 'Pending',
      frequency,
      customFrequency: customFrequency ? JSON.stringify(customFrequency) : null,
      startDate: new Date(startDate).getTime(),
      dueDate: new Date(dueDate).getTime(),
      contactName,
      contactEmail,
      contactPhone,
    });

    return NextResponse.json(result);
  } catch (error) {
    console.error('Error creating inspection:', error);
    return NextResponse.json({ error: 'Failed to create inspection' }, { status: 500 });
  }
}