import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { templates } from '@/lib/db/schema';
import { eq } from 'drizzle-orm';

export async function GET(
  request: Request,
  { params }: { params: { id: string } }
) {
  try {
    const template = await db.select().from(templates).where(eq(templates.id, params.id));
    
    if (!template.length) {
      return NextResponse.json({ error: 'Template not found' }, { status: 404 });
    }

    // Parse the sections JSON string
    const templateData = {
      ...template[0],
      sections: JSON.parse(template[0].sections),
    };

    return NextResponse.json(templateData);
  } catch (error) {
    console.error('Error fetching template:', error);
    return NextResponse.json({ error: 'Failed to fetch template' }, { status: 500 });
  }
}