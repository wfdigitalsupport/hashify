import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

// Mock settings table - in production, create a proper settings table
const settings = new Map();

export async function GET() {
  try {
    // In production, fetch from settings table
    const allSettings = Object.fromEntries(settings);
    return NextResponse.json(allSettings);
  } catch (error) {
    console.error('Error fetching settings:', error);
    return NextResponse.json({ error: 'Failed to fetch settings' }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    
    // In production, save to settings table
    Object.entries(body).forEach(([key, value]) => {
      settings.set(key, value);
    });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Error saving settings:', error);
    return NextResponse.json({ error: 'Failed to save settings' }, { status: 500 });
  }
}