"use client";

import { useState, useEffect } from "react";
import { GoogleMap, LoadScript, Marker, InfoWindow } from "@react-google-maps/api";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import Link from "next/link";
import { Loader2 } from "lucide-react";
import { toast } from "sonner";

interface Site {
  id: string;
  name: string;
  address: string;
  latitude: string;
  longitude: string;
}

interface Inspection {
  id: string;
  title: string;
  site: Site;
  inspector: {
    name: string;
  };
  priority: "High" | "Medium" | "Low";
  status: "Pending" | "In Progress" | "Completed";
  dueDate: number;
}

const priorityColors = {
  High: "destructive",
  Medium: "warning",
  Low: "secondary",
} as const;

const statusColors = {
  "In Progress": "warning",
  Pending: "secondary",
  Completed: "success",
} as const;

const mapContainerStyle = {
  width: "100%",
  height: "70vh",
};

const defaultCenter = {
  lat: 40.7128,
  lng: -74.0060,
};

export default function MapPage() {
  const [selectedLocation, setSelectedLocation] = useState<Inspection | null>(null);
  const [inspections, setInspections] = useState<Inspection[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchInspections();
  }, []);

  const fetchInspections = async () => {
    try {
      const response = await fetch('/api/inspections');
      if (!response.ok) throw new Error('Failed to fetch inspections');
      const data = await response.json();
      setInspections(data);
    } catch (error) {
      console.error('Error fetching inspections:', error);
      toast.error('Failed to load inspections');
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="space-y-1">
          <h1 className="text-3xl font-bold">Map</h1>
          <p className="text-muted-foreground">
            View inspection locations and team member positions.
          </p>
        </div>
      </div>

      <Card className="p-6">
        <LoadScript googleMapsApiKey={process.env.NEXT_PUBLIC_GOOGLE_MAPS_API_KEY || ""}>
          <GoogleMap
            mapContainerStyle={mapContainerStyle}
            center={defaultCenter}
            zoom={13}
          >
            {inspections.map((inspection) => (
              <Marker
                key={inspection.id}
                position={{
                  lat: parseFloat(inspection.site.latitude),
                  lng: parseFloat(inspection.site.longitude),
                }}
                onClick={() => setSelectedLocation(inspection)}
              />
            ))}

            {selectedLocation && (
              <InfoWindow
                position={{
                  lat: parseFloat(selectedLocation.site.latitude),
                  lng: parseFloat(selectedLocation.site.longitude),
                }}
                onCloseClick={() => setSelectedLocation(null)}
              >
                <div className="p-2 max-w-sm">
                  <h3 className="font-semibold mb-2">
                    <Link
                      href={`/inspections/${selectedLocation.id}`}
                      className="text-primary hover:underline"
                    >
                      {selectedLocation.title}
                    </Link>
                  </h3>
                  <div className="space-y-2 text-sm">
                    <p>
                      <strong>Site:</strong> {selectedLocation.site.name}
                    </p>
                    <p>
                      <strong>Address:</strong> {selectedLocation.site.address}
                    </p>
                    <p>
                      <strong>Inspector:</strong> {selectedLocation.inspector.name}
                    </p>
                    <p>
                      <strong>Due Date:</strong>{" "}
                      {new Date(selectedLocation.dueDate).toLocaleDateString()}
                    </p>
                    <div className="flex gap-2">
                      <Badge
                        variant={
                          priorityColors[selectedLocation.priority]
                        }
                      >
                        {selectedLocation.priority}
                      </Badge>
                      <Badge
                        variant={
                          statusColors[selectedLocation.status]
                        }
                      >
                        {selectedLocation.status}
                      </Badge>
                    </div>
                  </div>
                </div>
              </InfoWindow>
            )}
          </GoogleMap>
        </LoadScript>
      </Card>
    </div>
  );
}