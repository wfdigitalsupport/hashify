import { notFound } from "next/navigation";
import { InspectionForm } from "@/components/inspections/inspection-form";

// Mock data - replace with actual data fetching
const getInspection = (id: string) => {
  const inspection = {
    id: "INS-001",
    title: "Annual Safety Inspection",
    description: "Comprehensive safety inspection of all facilities and equipment",
    site: "Main Office",
    address: "123 Business Ave, Suite 100, Business City, BC 12345",
    inspector: {
      id: "1",
      name: "John Doe",
      avatar: "https://i.pravatar.cc/150?u=john",
    },
    priority: "High",
    status: "In Progress",
    dueDate: "2024-03-20",
    type: "Safety",
    tasks: [
      { id: "1", title: "Check fire extinguishers", completed: true },
      { id: "2", title: "Inspect emergency exits", completed: true },
      { id: "3", title: "Test alarm systems", completed: false },
      { id: "4", title: "Review safety protocols", completed: false },
    ],
  };

  if (id !== inspection.id) {
    return null;
  }

  return inspection;
};

export default function EditInspectionPage({
  params,
}: {
  params: { id: string };
}) {
  const inspection = getInspection(params.id);

  if (!inspection) {
    notFound();
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="space-y-1">
          <h1 className="text-3xl font-bold">Edit Inspection</h1>
          <p className="text-muted-foreground">
            Update inspection details and tasks.
          </p>
        </div>
      </div>
      <InspectionForm defaultValues={inspection} />
    </div>
  );
}