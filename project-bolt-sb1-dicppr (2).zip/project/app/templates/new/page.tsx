import { TemplateBuilder } from "@/components/templates/template-builder";

export default function NewTemplatePage() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="space-y-1">
          <h1 className="text-3xl font-bold">New Template</h1>
          <p className="text-muted-foreground">
            Create a new inspection template using the form builder.
          </p>
        </div>
      </div>
      <TemplateBuilder />
    </div>
  );
}