import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import { generateRandomColor } from '../utils/colors';
import type { MapState, RegionData } from '../types';

const initialState: MapState = {
  regions: {},
  selectedStates: {},
  style: {
    showBackground: true,
    borderColor: '#000000',
    showLabels: true,
  },
};

const mapSlice = createSlice({
  name: 'map',
  initialState,
  reducers: {
    selectState: (state, action: PayloadAction<{ state: string; name: string }>) => {
      const { state: stateCode, name } = action.payload;
      const regionKey = `region_${Object.keys(state.regions).length}`;
      
      if (!state.regions[regionKey]) {
        state.regions[regionKey] = {
          label: name,
          color: generateRandomColor(),
        };
      }
      
      state.selectedStates[stateCode] = regionKey;
    },
    deselectState: (state, action: PayloadAction<string>) => {
      const stateCode = action.payload;
      const regionKey = state.selectedStates[stateCode];
      
      delete state.selectedStates[stateCode];
      
      // Remove region if it has no more selections
      const hasStatesSelected = Object.values(state.selectedStates).includes(regionKey);
      if (!hasStatesSelected && regionKey) {
        delete state.regions[regionKey];
      }
    },
    updateRegion: (state, action: PayloadAction<{ key: string; label?: string; color?: string }>) => {
      const { key, label, color } = action.payload;
      if (state.regions[key]) {
        if (label !== undefined) state.regions[key].label = label;
        if (color !== undefined) state.regions[key].color = color;
      }
    },
    removeRegion: (state, action: PayloadAction<string>) => {
      const regionKey = action.payload;
      delete state.regions[regionKey];
      
      // Remove associated selections
      const newSelectedStates = { ...state.selectedStates };
      Object.entries(state.selectedStates).forEach(([id, key]) => {
        if (key === regionKey) {
          delete newSelectedStates[id];
        }
      });
      state.selectedStates = newSelectedStates;
    },
    updateStyle: (state, action: PayloadAction<Partial<typeof initialState.style>>) => {
      state.style = { ...state.style, ...action.payload };
    },
  },
});

export const {
  selectState,
  deselectState,
  updateRegion,
  removeRegion,
  updateStyle,
} = mapSlice.actions;

export default mapSlice.reducer;