export interface MapMarker {
  id: string;
  imageUrl?: string;
  title: string;
  description?: string;
  destinationUrl?: string;
  address?: string;
  latitude: number;
  longitude: number;
  postalCode?: string;
  easting?: number;
  northing?: number;
  legendCategory?: string;
  customIcon?: string;
}

export interface MapStyle {
  showBackground: boolean;
  borderColor: string;
  showLabels: boolean;
}

export interface RegionData {
  label: string;
  color: string;
}

export interface MapState {
  regions: Record<string, RegionData>;
  selectedStates: Record<string, string>;
  style: MapStyle;
}