export const MAP_CONFIG = {
  style: {
    version: 8,
    sources: {
      osm: {
        type: 'raster',
        tiles: ['https://tile.openstreetmap.org/{z}/{x}/{y}.png'],
        tileSize: 256,
        attribution: '&copy; OpenStreetMap Contributors',
        maxzoom: 19
      }
    },
    layers: [
      {
        id: 'osm',
        type: 'raster',
        source: 'osm',
        minzoom: 0,
        maxzoom: 19
      }
    ]
  },
  center: [-98.5795, 39.8283], // Center of USA
  zoom: 3,
  minZoom: 2,
  maxZoom: 8,
} as const;

export const REGIONS = {
  WEST: {
    name: 'West',
    color: '#ff9999',
    states: ['CA', 'OR', 'WA', 'NV', 'ID', 'MT', 'WY', 'AK', 'HI'],
  },
  SOUTHWEST: {
    name: 'Southwest',
    color: '#ffff99',
    states: ['AZ', 'NM', 'TX', 'OK'],
  },
  MIDWEST: {
    name: 'Midwest',
    color: '#99ff99',
    states: ['ND', 'SD', 'NE', 'KS', 'MN', 'IA', 'MO', 'WI', 'IL', 'IN', 'MI', 'OH'],
  },
  NORTHEAST: {
    name: 'Northeast',
    color: '#ff99ff',
    states: ['ME', 'NH', 'VT', 'MA', 'RI', 'CT', 'NY', 'PA', 'NJ', 'DE', 'MD', 'DC'],
  },
  SOUTHEAST: {
    name: 'Southeast',
    color: '#9999ff',
    states: ['VA', 'WV', 'KY', 'NC', 'SC', 'TN', 'GA', 'AL', 'MS', 'AR', 'LA', 'FL'],
  },
} as const;