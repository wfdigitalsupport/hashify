import React, { useEffect, useRef } from 'react';
import * as maptilersdk from '@maptiler/sdk';
import { useSelector } from 'react-redux';
import type { RootState } from '../store';
import { MAPTILER_API_KEY, DEFAULT_CENTER, DEFAULT_ZOOM } from '../config/constants';
import '@maptiler/sdk/dist/maptiler-sdk.css';
import '../styles/map.css';

const Map: React.FC = () => {
  const mapContainer = useRef<HTMLDivElement>(null);
  const map = useRef<maptilersdk.Map | null>(null);
  const { center, zoom, markers, style } = useSelector((state: RootState) => state.map);

  useEffect(() => {
    if (!map.current && mapContainer.current) {
      maptilersdk.config.apiKey = MAPTILER_API_KEY;
      
      map.current = new maptilersdk.Map({
        container: mapContainer.current,
        style: maptilersdk.MapStyle.STREETS,
        center: DEFAULT_CENTER,
        zoom: DEFAULT_ZOOM,
      });

      map.current.on('load', () => {
        if (map.current) {
          map.current.resize();
        }
      });
    }

    return () => {
      if (map.current) {
        map.current.remove();
        map.current = null;
      }
    };
  }, []);

  useEffect(() => {
    if (map.current) {
      map.current.setCenter(center);
      map.current.setZoom(zoom);
    }
  }, [center, zoom]);

  useEffect(() => {
    if (!map.current) return;

    // Clear existing markers
    const existingMarkers = document.getElementsByClassName('marker');
    Array.from(existingMarkers).forEach(marker => marker.remove());

    // Add markers
    markers.forEach(marker => {
      const el = document.createElement('div');
      el.className = 'marker';
      el.style.width = '24px';
      el.style.height = '24px';
      el.style.backgroundImage = marker.customIcon || 'url(https://docs.maptiler.com/sdk-js/assets/marker.png)';
      el.style.backgroundSize = 'cover';

      new maptilersdk.Marker({ element: el })
        .setLngLat([marker.longitude, marker.latitude])
        .setPopup(new maptilersdk.Popup().setHTML(
          `<div class="p-2">
            <h3 class="font-bold text-lg mb-2">${marker.title}</h3>
            ${marker.description ? `<p class="text-gray-600 mb-2">${marker.description}</p>` : ''}
            ${marker.destinationUrl ? `<a href="${marker.destinationUrl}" target="_blank" class="text-blue-500 hover:text-blue-600">Learn more →</a>` : ''}
          </div>`
        ))
        .addTo(map.current);
    });
  }, [markers]);

  return (
    <div className="relative rounded-lg overflow-hidden shadow-lg">
      <div ref={mapContainer} className="mapContainer" />
    </div>
  );
};

export default Map;