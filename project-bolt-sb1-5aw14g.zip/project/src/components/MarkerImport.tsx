import React, { useCallback } from 'react';
import { useDispatch } from 'react-redux';
import Papa from 'papaparse';
import { Upload } from 'lucide-react';
import { importMarkers } from '../store/mapSlice';
import type { MapMarker } from '../types';

const MarkerImport: React.FC = () => {
  const dispatch = useDispatch();

  const handleFileUpload = useCallback((event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    Papa.parse(file, {
      header: true,
      complete: (results) => {
        const markers = results.data.map((row: any) => ({
          id: crypto.randomUUID(),
          imageUrl: row.image_url,
          title: row.title,
          description: row.description,
          destinationUrl: row.destination_url,
          address: row.address,
          latitude: parseFloat(row.latitude),
          longitude: parseFloat(row.longitude),
          postalCode: row.postal_code,
          easting: parseFloat(row.easting),
          northing: parseFloat(row.northing),
          legendCategory: row.legend_category,
          customIcon: row.custom_icon,
        }));
        dispatch(importMarkers(markers as MapMarker[]));
      },
    });
  }, [dispatch]);

  return (
    <div className="p-4 bg-white rounded-lg shadow-lg">
      <div className="flex items-center gap-2 mb-4">
        <Upload className="w-5 h-5" />
        <h2 className="text-lg font-semibold">Import Markers</h2>
      </div>

      <label className="block">
        <span className="sr-only">Choose CSV file</span>
        <input
          type="file"
          accept=".csv"
          onChange={handleFileUpload}
          className="block w-full text-sm text-gray-500
            file:mr-4 file:py-2 file:px-4
            file:rounded-full file:border-0
            file:text-sm file:font-semibold
            file:bg-blue-50 file:text-blue-700
            hover:file:bg-blue-100"
        />
      </label>
    </div>
  );
};

export default MarkerImport;