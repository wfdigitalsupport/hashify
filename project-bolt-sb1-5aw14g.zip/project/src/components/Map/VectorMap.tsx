import React, { useEffect, useRef } from 'react';
import maplibregl from 'maplibre-gl';
import { useSelector, useDispatch } from 'react-redux';
import { selectState, deselectState } from '../../store/mapSlice';
import type { RootState } from '../../store';
import 'maplibre-gl/dist/maplibre-gl.css';

const VectorMap: React.FC = () => {
  const mapContainer = useRef<HTMLDivElement>(null);
  const map = useRef<maplibregl.Map | null>(null);
  const dispatch = useDispatch();
  const { regions, selectedStates } = useSelector((state: RootState) => state.map);

  useEffect(() => {
    if (!mapContainer.current || map.current) return;

    map.current = new maplibregl.Map({
      container: mapContainer.current,
      style: {
        version: 8,
        sources: {
          openmaptiles: {
            type: 'vector',
            url: 'https://api.maptiler.com/tiles/v3/tiles.json?key=aCY9azCxDFA3h4haR5fx'
          }
        },
        layers: [
          {
            id: 'background',
            type: 'background',
            paint: {
              'background-color': '#f8fafc'
            }
          },
          {
            id: 'state-fills',
            type: 'fill',
            source: 'openmaptiles',
            'source-layer': 'place',
            filter: ['==', 'class', 'state'],
            paint: {
              'fill-color': [
                'case',
                ['has', ['get', 'name'], ['literal', selectedStates]],
                ['get', ['get', 'name'], ['literal', regions]],
                '#ffffff'
              ],
              'fill-opacity': 0.7
            }
          },
          {
            id: 'state-borders',
            type: 'line',
            source: 'openmaptiles',
            'source-layer': 'place',
            filter: ['==', 'class', 'state'],
            paint: {
              'line-color': '#000000',
              'line-width': 1
            }
          },
          {
            id: 'state-labels',
            type: 'symbol',
            source: 'openmaptiles',
            'source-layer': 'place',
            filter: ['==', 'class', 'state'],
            layout: {
              'text-field': ['get', 'name'],
              'text-size': 12,
              'text-allow-overlap': false
            },
            paint: {
              'text-color': '#000000',
              'text-halo-color': '#ffffff',
              'text-halo-width': 1
            }
          }
        ]
      },
      center: [-98.5795, 39.8283],
      zoom: 3,
      minZoom: 2,
      maxZoom: 8
    });

    map.current.on('click', 'state-fills', (e) => {
      if (!e.features?.length) return;

      const feature = e.features[0];
      const stateName = feature.properties?.name;
      
      if (stateName) {
        if (selectedStates[stateName]) {
          dispatch(deselectState(stateName));
        } else {
          dispatch(selectState({ state: stateName, name: stateName }));
        }
      }
    });

    map.current.on('mouseenter', 'state-fills', () => {
      if (map.current) {
        map.current.getCanvas().style.cursor = 'pointer';
      }
    });

    map.current.on('mouseleave', 'state-fills', () => {
      if (map.current) {
        map.current.getCanvas().style.cursor = '';
      }
    });

    return () => {
      if (map.current) {
        map.current.remove();
        map.current = null;
      }
    };
  }, [dispatch]);

  useEffect(() => {
    if (!map.current || !map.current.isStyleLoaded()) return;

    map.current.setPaintProperty('state-fills', 'fill-color', [
      'case',
      ['has', ['get', 'name'], ['literal', selectedStates]],
      ['get', ['get', 'name'], ['literal', regions]],
      '#ffffff'
    ]);
  }, [regions, selectedStates]);

  return <div ref={mapContainer} className="w-full h-full" />;
};

export default VectorMap;