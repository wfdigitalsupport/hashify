import React, { useEffect, useRef, useState } from 'react';
import { select } from 'd3-selection';
import { zoom as d3Zoom } from 'd3-zoom';
import { useDispatch, useSelector } from 'react-redux';
import { selectRegion, deselectRegion } from '../../store/mapSlice';
import { useMapProjection } from './hooks/useMapProjection';
import MapPath from './MapPath';
import { worldMapData } from '../../data/world-map';
import type { RootState } from '../../store';

const WorldMap: React.FC = () => {
  const svgRef = useRef<SVGSVGElement>(null);
  const [dimensions, setDimensions] = useState({ width: 800, height: 600 });
  const dispatch = useDispatch();
  const { regions, selectedRegions } = useSelector((state: RootState) => state.map);

  const { pathGenerator } = useMapProjection(dimensions.width, dimensions.height);

  useEffect(() => {
    const updateDimensions = () => {
      if (svgRef.current) {
        const { width, height } = svgRef.current.parentElement?.getBoundingClientRect() || 
          { width: 800, height: 600 };
        setDimensions({ width, height });
      }
    };

    updateDimensions();
    window.addEventListener('resize', updateDimensions);
    return () => window.removeEventListener('resize', updateDimensions);
  }, []);

  useEffect(() => {
    if (!svgRef.current) return;

    const svg = select(svgRef.current);
    const zoom = d3Zoom()
      .scaleExtent([1, 8])
      .on('zoom', (event) => {
        svg.select('g').attr('transform', event.transform);
      });

    svg.call(zoom as any);
  }, [dimensions]);

  const handleRegionClick = (regionId: string) => {
    if (selectedRegions[regionId]) {
      dispatch(deselectRegion(regionId));
    } else {
      dispatch(selectRegion({
        id: regionId,
        name: worldMapData.features.find(f => f.properties.id === regionId)?.properties.name || regionId
      }));
    }
  };

  return (
    <svg
      ref={svgRef}
      width={dimensions.width}
      height={dimensions.height}
      className="w-full h-full bg-gray-50"
    >
      <g>
        {worldMapData.features.map((feature) => {
          const regionId = feature.properties.id;
          const regionKey = selectedRegions[regionId];
          const region = regions[regionKey];

          return (
            <MapPath
              key={regionId}
              feature={feature}
              pathGenerator={pathGenerator}
              isSelected={!!region}
              color={region?.color || '#ffffff'}
              onClick={() => handleRegionClick(regionId)}
              onMouseEnter={() => {
                if (svgRef.current) {
                  svgRef.current.style.cursor = 'pointer';
                }
              }}
              onMouseLeave={() => {
                if (svgRef.current) {
                  svgRef.current.style.cursor = '';
                }
              }}
            />
          );
        })}
      </g>
    </svg>
  );
};

export default WorldMap;