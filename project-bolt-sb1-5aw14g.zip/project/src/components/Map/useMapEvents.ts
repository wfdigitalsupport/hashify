import { useEffect } from 'react';
import maplibregl from 'maplibre-gl';
import { useDispatch } from 'react-redux';
import { selectState, deselectState } from '../../store/mapSlice';

export const useMapEvents = (map: maplibregl.Map | null) => {
  const dispatch = useDispatch();

  useEffect(() => {
    if (!map) return;

    const handleStateClick = (e: maplibregl.MapMouseEvent & { features?: maplibregl.MapboxGeoJSONFeature[] }) => {
      if (!e.features?.length) return;

      const feature = e.features[0];
      const stateCode = feature.properties?.postal;
      
      if (stateCode) {
        // Toggle state selection
        if (feature.state?.selected) {
          dispatch(deselectState(stateCode));
        } else {
          dispatch(selectState({ state: stateCode, region: 'WEST' })); // Default to WEST region
        }
      }
    };

    map.on('click', 'state-fills', handleStateClick);

    return () => {
      map.off('click', 'state-fills', handleStateClick);
    };
  }, [map, dispatch]);
};