import React from 'react';
import { Download } from 'lucide-react';
import html2canvas from 'html2canvas';

const ExportButton: React.FC = () => {
  const handleExport = async () => {
    const mapElement = document.querySelector('.map-container');
    if (!mapElement) return;

    try {
      const canvas = await html2canvas(mapElement as HTMLElement);
      
      // For PNG
      const pngUrl = canvas.toDataURL('image/png');
      const pngLink = document.createElement('a');
      pngLink.download = 'map-export.png';
      pngLink.href = pngUrl;
      pngLink.click();

      // For SVG
      const svgData = new XMLSerializer().serializeToString(mapElement.querySelector('svg')!);
      const svgBlob = new Blob([svgData], { type: 'image/svg+xml;charset=utf-8' });
      const svgUrl = URL.createObjectURL(svgBlob);
      const svgLink = document.createElement('a');
      svgLink.download = 'map-export.svg';
      svgLink.href = svgUrl;
      svgLink.click();
      URL.revokeObjectURL(svgUrl);
    } catch (error) {
      console.error('Error exporting map:', error);
    }
  };

  return (
    <button
      onClick={handleExport}
      className="fixed bottom-4 right-4 bg-blue-600 text-white px-4 py-2 rounded-lg shadow-lg flex items-center gap-2 hover:bg-blue-700 transition-colors"
    >
      <Download className="w-4 h-4" />
      Export Map
    </button>
  );
};

export default ExportButton;