import { useCallback } from 'react';
import { geoMercator, geoPath } from 'd3-geo';

export const useMapProjection = (width: number, height: number) => {
  const projection = useCallback(() => {
    return geoMercator()
      .scale(Math.min(width, height) / 2 / Math.PI)
      .translate([width / 2, height / 2]);
  }, [width, height]);

  const pathGenerator = useCallback(() => {
    return geoPath().projection(projection());
  }, [projection]);

  return { projection, pathGenerator };
};