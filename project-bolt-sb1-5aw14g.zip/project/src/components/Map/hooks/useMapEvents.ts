import { useEffect } from 'react';
import maplibregl from 'maplibre-gl';
import { useDispatch } from 'react-redux';
import { selectState, deselectState } from '../../../store/mapSlice';

export const useMapEvents = (map: maplibregl.Map | null) => {
  const dispatch = useDispatch();

  useEffect(() => {
    if (!map) return;

    const handleStateClick = (e: maplibregl.MapMouseEvent & { features?: maplibregl.MapboxGeoJSONFeature[] }) => {
      if (!e.features?.length) return;

      const feature = e.features[0];
      const stateCode = feature.properties?.postal;
      
      if (stateCode) {
        if (feature.state?.selected) {
          dispatch(deselectState(stateCode));
        } else {
          // Select first available region by default
          dispatch(selectState({ state: stateCode, region: 'WEST' }));
        }
      }
    };

    const handleMouseEnter = () => {
      map.getCanvas().style.cursor = 'pointer';
    };

    const handleMouseLeave = () => {
      map.getCanvas().style.cursor = '';
    };

    map.on('click', 'state-fills', handleStateClick);
    map.on('mouseenter', 'state-fills', handleMouseEnter);
    map.on('mouseleave', 'state-fills', handleMouseLeave);

    return () => {
      map.off('click', 'state-fills', handleStateClick);
      map.off('mouseenter', 'state-fills', handleMouseEnter);
      map.off('mouseleave', 'state-fills', handleMouseLeave);
    };
  }, [map, dispatch]);
};