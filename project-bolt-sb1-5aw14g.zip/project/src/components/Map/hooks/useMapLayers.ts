import { useEffect } from 'react';
import maplibregl from 'maplibre-gl';
import type { RegionData } from '../../../types';

export const useMapLayers = (
  map: maplibregl.Map | null,
  regions: Record<string, RegionData>,
  selectedStates: Record<string, string>
) => {
  useEffect(() => {
    if (!map) return;

    const initializeLayers = () => {
      // Add states source
      if (!map.getSource('states')) {
        map.addSource('states', {
          type: 'vector',
          url: 'https://api.maptiler.com/tiles/v3/tiles.json?key=aCY9azCxDFA3h4haR5fx'
        });
      }

      // Add state fills layer
      if (!map.getLayer('state-fills')) {
        map.addLayer({
          id: 'state-fills',
          type: 'fill',
          source: 'states',
          'source-layer': 'states',
          paint: {
            'fill-color': [
              'case',
              ['has', ['get', 'postal'], ['literal', selectedStates]],
              ['get', ['get', 'postal'], ['literal', regions]],
              'rgba(255, 255, 255, 0.5)'
            ],
            'fill-opacity': 0.7
          }
        });
      }

      // Add state borders layer
      if (!map.getLayer('state-borders')) {
        map.addLayer({
          id: 'state-borders',
          type: 'line',
          source: 'states',
          'source-layer': 'states',
          paint: {
            'line-color': '#000000',
            'line-width': 1
          }
        });
      }

      // Add state labels
      if (!map.getLayer('state-labels')) {
        map.addLayer({
          id: 'state-labels',
          type: 'symbol',
          source: 'states',
          'source-layer': 'states',
          layout: {
            'text-field': ['get', 'postal'],
            'text-size': 12,
            'text-allow-overlap': false
          },
          paint: {
            'text-color': '#000000',
            'text-halo-color': '#ffffff',
            'text-halo-width': 1
          }
        });
      }
    };

    if (map.isStyleLoaded()) {
      initializeLayers();
    } else {
      map.on('style.load', initializeLayers);
    }

    return () => {
      map.off('style.load', initializeLayers);
    };
  }, [map]);

  // Update colors when regions or selectedStates change
  useEffect(() => {
    if (!map || !map.isStyleLoaded()) return;

    map.setPaintProperty('state-fills', 'fill-color', [
      'case',
      ['has', ['get', 'postal'], ['literal', selectedStates]],
      ['get', ['get', 'postal'], ['literal', regions]],
      'rgba(255, 255, 255, 0.5)'
    ]);
  }, [map, regions, selectedStates]);
};