import React, { useRef, useState } from 'react';
import { useSelector } from 'react-redux';
import { GripHorizontal } from 'lucide-react';
import type { RootState } from '../../store';

const Legend: React.FC = () => {
  const { regions } = useSelector((state: RootState) => state.map);
  const legendRef = useRef<HTMLDivElement>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [position, setPosition] = useState({ x: 20, y: 20 });
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 });

  const handleMouseDown = (e: React.MouseEvent) => {
    setIsDragging(true);
    setDragStart({
      x: e.clientX - position.x,
      y: e.clientY - position.y
    });
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDragging) return;
    
    setPosition({
      x: e.clientX - dragStart.x,
      y: e.clientY - dragStart.y
    });
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  if (Object.keys(regions).length === 0) return null;

  return (
    <div
      ref={legendRef}
      className="absolute bg-white rounded-lg shadow-lg p-4 cursor-move"
      style={{
        left: position.x,
        top: position.y,
        zIndex: 1000,
        minWidth: '200px'
      }}
      onMouseDown={handleMouseDown}
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUp}
      onMouseLeave={handleMouseUp}
    >
      <div className="flex items-center justify-between mb-2">
        <h3 className="text-sm font-semibold">Map Legend</h3>
        <GripHorizontal className="w-4 h-4 text-gray-400" />
      </div>
      <div className="space-y-2">
        {Object.entries(regions).map(([key, region]) => (
          <div key={key} className="flex items-center gap-2">
            <div
              className="w-4 h-4 rounded"
              style={{ backgroundColor: region.color }}
            />
            <span className="text-sm">{region.label}</span>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Legend;