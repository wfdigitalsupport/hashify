import maplibregl from 'maplibre-gl';
import type { StateLayer } from './types';

export const STATE_LAYER: StateLayer = {
  id: 'state-fills',
  source: 'states',
  sourceLayer: 'admin1',
};

export const addStateLayers = (map: maplibregl.Map, selectedStates: Record<string, string>, regions: Record<string, { color: string }>) => {
  // Add source if it doesn't exist
  if (!map.getSource(STATE_LAYER.source)) {
    map.addSource(STATE_LAYER.source, {
      type: 'vector',
      url: 'https://api.maptiler.com/tiles/v3-openmaptiles/tiles.json?key=aCY9azCxDFA3h4haR5fx',
      tiles: ['https://api.maptiler.com/tiles/v3-openmaptiles/{z}/{x}/{y}.pbf?key=aCY9azCxDFA3h4haR5fx'],
    });
  }

  // Add fill layer
  if (!map.getLayer(STATE_LAYER.id)) {
    map.addLayer({
      id: STATE_LAYER.id,
      type: 'fill',
      source: STATE_LAYER.source,
      'source-layer': STATE_LAYER.sourceLayer,
      paint: {
        'fill-color': [
          'case',
          ['has', ['get', 'postal'], ['literal', selectedStates]],
          ['get', ['get', 'postal'], ['literal', regions]],
          '#ffffff'
        ],
        'fill-opacity': 0.7,
      },
    });

    // Add border layer
    map.addLayer({
      id: 'state-borders',
      type: 'line',
      source: STATE_LAYER.source,
      'source-layer': STATE_LAYER.sourceLayer,
      paint: {
        'line-color': '#000000',
        'line-width': 1,
      },
    });

    // Add click handler
    map.on('click', STATE_LAYER.id, (e) => {
      if (e.features && e.features[0]) {
        const feature = e.features[0];
        const stateCode = feature.properties?.postal;
        if (stateCode) {
          // Dispatch state selection action
          // This will be handled by the click handler in MapContainer
        }
      }
    });
  }
};

export const updateStateColors = (
  map: maplibregl.Map,
  selectedStates: Record<string, string>,
  regions: Record<string, { color: string }>,
) => {
  if (map.getLayer(STATE_LAYER.id)) {
    map.setPaintProperty(STATE_LAYER.id, 'fill-color', [
      'case',
      ['has', ['get', 'postal'], ['literal', selectedStates]],
      ['get', ['get', 'postal'], ['literal', regions]],
      '#ffffff'
    ]);
  }
};