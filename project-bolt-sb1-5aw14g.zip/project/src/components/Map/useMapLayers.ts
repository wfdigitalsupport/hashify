import { useEffect } from 'react';
import maplibregl from 'maplibre-gl';
import type { RegionData } from '../../types';

export const useMapLayers = (
  map: maplibregl.Map | null,
  regions: Record<string, RegionData>,
  selectedStates: Record<string, string>
) => {
  useEffect(() => {
    if (!map) return;

    map.on('load', () => {
      // Add states source
      if (!map.getSource('states')) {
        map.addSource('states', {
          type: 'vector',
          url: 'https://api.maptiler.com/tiles/us-states/tiles.json?key=aCY9azCxDFA3h4haR5fx'
        });
      }

      // Add state fills layer
      if (!map.getLayer('state-fills')) {
        map.addLayer({
          id: 'state-fills',
          type: 'fill',
          source: 'states',
          'source-layer': 'states',
          paint: {
            'fill-color': [
              'case',
              ['has', ['get', 'postal'], ['literal', selectedStates]],
              ['get', ['get', 'postal'], ['literal', regions]],
              '#ffffff'
            ],
            'fill-opacity': 0.7
          }
        });
      }

      // Add state borders layer
      if (!map.getLayer('state-borders')) {
        map.addLayer({
          id: 'state-borders',
          type: 'line',
          source: 'states',
          'source-layer': 'states',
          paint: {
            'line-color': '#000000',
            'line-width': 1
          }
        });
      }
    });
  }, [map]);

  // Update colors when regions or selectedStates change
  useEffect(() => {
    if (!map || !map.isStyleLoaded()) return;

    map.setPaintProperty('state-fills', 'fill-color', [
      'case',
      ['has', ['get', 'postal'], ['literal', selectedStates]],
      ['get', ['get', 'postal'], ['literal', regions]],
      '#ffffff'
    ]);
  }, [map, regions, selectedStates]);
};