import React, { useEffect, useRef, useState } from 'react';
import { geoAlbersUsa, geoPath } from 'd3-geo';
import { zoom as d3Zoom, zoomIdentity } from 'd3-zoom';
import { select } from 'd3-selection';
import { useSelector, useDispatch } from 'react-redux';
import { selectState, deselectState } from '../../store/mapSlice';
import type { RootState } from '../../store';
import { usStatesData } from '../../data/us-states-data';

const SVGMap: React.FC = () => {
  const svgRef = useRef<SVGSVGElement>(null);
  const [dimensions, setDimensions] = useState({ width: 0, height: 0 });
  const dispatch = useDispatch();
  const { regions, selectedStates } = useSelector((state: RootState) => state.map);

  useEffect(() => {
    const updateDimensions = () => {
      if (svgRef.current) {
        const { width, height } = svgRef.current.parentElement?.getBoundingClientRect() || { width: 800, height: 600 };
        setDimensions({ width, height });
      }
    };

    updateDimensions();
    window.addEventListener('resize', updateDimensions);
    return () => window.removeEventListener('resize', updateDimensions);
  }, []);

  useEffect(() => {
    if (!svgRef.current || !dimensions.width) return;

    const svg = select(svgRef.current);
    
    // Use Albers USA projection to handle Alaska and Hawaii correctly
    const projection = geoAlbersUsa()
      .fitSize([dimensions.width, dimensions.height], usStatesData);
    
    const path = geoPath().projection(projection);

    // Setup zoom behavior
    const zoom = d3Zoom()
      .scaleExtent([0.5, 8])
      .translateExtent([[0, 0], [dimensions.width, dimensions.height]])
      .on('zoom', (event) => {
        svg.select('g').attr('transform', event.transform);
      });

    svg.call(zoom as any);
    svg.call(zoom.transform as any, zoomIdentity);

    // Draw states with accurate boundaries
    const statesGroup = svg.select('g.states');
    statesGroup.selectAll('path')
      .data(usStatesData.features)
      .join('path')
      .attr('d', path as any)
      .attr('class', 'state-path')
      .attr('id', (d) => `state-${d.properties.postal}`)
      .style('fill', (d) => {
        const stateCode = d.properties.postal;
        const regionKey = selectedStates[stateCode];
        return regionKey ? regions[regionKey]?.color || '#ffffff' : '#ffffff';
      })
      .style('stroke', '#000')
      .style('stroke-width', '0.5')
      .style('vector-effect', 'non-scaling-stroke')
      .on('click', (event, d) => {
        event.preventDefault();
        const stateCode = d.properties.postal;
        if (selectedStates[stateCode]) {
          dispatch(deselectState(stateCode));
        } else {
          dispatch(selectState({ 
            state: stateCode, 
            name: d.properties.name 
          }));
        }
      })
      .on('mouseenter', function() {
        select(this)
          .style('opacity', 0.8)
          .style('cursor', 'pointer');
      })
      .on('mouseleave', function() {
        select(this)
          .style('opacity', 1)
          .style('cursor', 'default');
      });

    // Add state labels
    statesGroup.selectAll('text')
      .data(usStatesData.features)
      .join('text')
      .attr('x', (d) => {
        const centroid = path.centroid(d);
        return centroid[0];
      })
      .attr('y', (d) => {
        const centroid = path.centroid(d);
        return centroid[1];
      })
      .attr('text-anchor', 'middle')
      .attr('dominant-baseline', 'central')
      .style('font-size', '8px')
      .style('pointer-events', 'none')
      .style('user-select', 'none')
      .style('font-weight', 'bold')
      .style('text-shadow', '1px 1px 1px white')
      .text((d) => d.properties.postal);
  }, [dimensions, regions, selectedStates, dispatch]);

  return (
    <svg
      ref={svgRef}
      width={dimensions.width}
      height={dimensions.height}
      className="w-full h-full"
      style={{ background: '#f8fafc' }}
    >
      <g className="states" />
    </svg>
  );
};

export default SVGMap;