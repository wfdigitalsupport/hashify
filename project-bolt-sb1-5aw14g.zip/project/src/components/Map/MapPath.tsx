import React from 'react';
import { Feature } from 'geojson';

interface MapPathProps {
  feature: Feature;
  pathGenerator: (feature: Feature) => string | null;
  isSelected: boolean;
  color: string;
  onClick: () => void;
  onMouseEnter: () => void;
  onMouseLeave: () => void;
}

const MapPath: React.FC<MapPathProps> = ({
  feature,
  pathGenerator,
  isSelected,
  color,
  onClick,
  onMouseEnter,
  onMouseLeave
}) => {
  return (
    <path
      d={pathGenerator(feature) || ''}
      fill={isSelected ? color : '#ffffff'}
      stroke="#000000"
      strokeWidth={0.5}
      className="transition-colors duration-200 hover:opacity-80"
      onClick={onClick}
      onMouseEnter={onMouseEnter}
      onMouseLeave={onMouseLeave}
    />
  );
};

export default MapPath;