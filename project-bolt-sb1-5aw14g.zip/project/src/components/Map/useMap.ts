import { useEffect, useRef, MutableRefObject } from 'react';
import maplibregl from 'maplibre-gl';
import { MAP_CONFIG } from '../../config/constants';
import type { MapRef } from './types';

export const useMap = (container: MutableRefObject<HTMLDivElement | null>): MapRef => {
  const map = useRef<maplibregl.Map | null>(null);
  const isLoaded = useRef<boolean>(false);

  useEffect(() => {
    if (!map.current && container.current) {
      map.current = new maplibregl.Map({
        container: container.current,
        style: MAP_CONFIG.style,
        center: MAP_CONFIG.center,
        zoom: MAP_CONFIG.zoom,
        minZoom: MAP_CONFIG.minZoom,
        maxZoom: MAP_CONFIG.maxZoom,
      });

      map.current.on('load', () => {
        isLoaded.current = true;
      });
    }

    return () => {
      if (map.current) {
        map.current.remove();
        map.current = null;
        isLoaded.current = false;
      }
    };
  }, [container]);

  return { map, isLoaded };
};