import { MutableRefObject } from 'react';
import maplibregl from 'maplibre-gl';

export interface MapRef {
  map: MutableRefObject<maplibregl.Map | null>;
  isLoaded: MutableRefObject<boolean>;
}

export interface StateLayer {
  id: string;
  source: string;
  sourceLayer: string;
}