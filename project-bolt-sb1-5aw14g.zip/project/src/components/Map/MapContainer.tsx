import React from 'react';
import SVGMap from './SVGMap';
import Legend from './Legend';
import ExportButton from './ExportButton';

const MapContainer: React.FC = () => {
  return (
    <div className="absolute inset-0 bg-gray-50 map-container">
      <SVGMap />
      <Legend />
      <ExportButton />
    </div>
  );
};

export default MapContainer;