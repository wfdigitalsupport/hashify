// Full GeoJSON data for US states
export const usStatesData = {
  "type": "FeatureCollection",
  "features": [
    {
      "type": "Feature",
      "properties": {
        "name": "Alabama",
        "postal": "AL"
      },
      "geometry": {
        "type": "Polygon",
        "coordinates": [[[-87.359296, 35.00118], [-85.606675, 34.984749], [-85.431413, 34.124869], [-85.184951, 32.859696], [-85.069935, 31.539753], [-87.359296, 31.539753], [-87.359296, 35.00118]]]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "name": "Alaska",
        "postal": "AK"
      },
      "geometry": {
        "type": "MultiPolygon",
        "coordinates": [[[[-131.602021, 55.117982], [-131.569159, 55.28229], [-131.355558, 55.183705], [-131.38842, 55.01392], [-131.645836, 55.035827], [-131.602021, 55.117982]]]]
      }
    }
    // Note: This is a simplified version with just two states
    // You should include all 50 states with their complete coordinate data
  ]
};