import React from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Grid } from 'lucide-react';
import { updateStyle } from '../../store/mapSlice';
import type { RootState } from '../../store';
import { ControlSection } from './ControlSection';

export const PatternControls: React.FC = () => {
  const dispatch = useDispatch();
  const style = useSelector((state: RootState) => state.map.style);

  return (
    <ControlSection title="Pattern Overlay" icon={<Grid className="w-4 h-4" />}>
      <div className="space-y-2">
        <select
          value={style.pattern}
          onChange={(e) => dispatch(updateStyle({ pattern: e.target.value }))}
          className="block w-full mt-1 rounded-md border-gray-300 shadow-sm"
        >
          <option value="">None</option>
          <option value="dots">Dots</option>
          <option value="lines">Lines</option>
          <option value="grid">Grid</option>
        </select>

        {style.pattern && (
          <input
            type="range"
            min="0"
            max="1"
            step="0.1"
            value={style.patternOpacity || 0.5}
            onChange={(e) => dispatch(updateStyle({ patternOpacity: parseFloat(e.target.value) }))}
            className="block w-full mt-1"
          />
        )}
      </div>
    </ControlSection>
  );
};