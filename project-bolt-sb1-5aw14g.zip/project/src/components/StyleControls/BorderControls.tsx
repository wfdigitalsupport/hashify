import React from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Square } from 'lucide-react';
import { updateStyle } from '../../store/mapSlice';
import type { RootState } from '../../store';
import { ControlSection } from './ControlSection';

export const BorderControls: React.FC = () => {
  const dispatch = useDispatch();
  const style = useSelector((state: RootState) => state.map.style);

  return (
    <ControlSection title="Border" icon={<Square className="w-4 h-4" />}>
      <div className="space-y-2">
        <select
          value={style.borderStyle}
          onChange={(e) => dispatch(updateStyle({ borderStyle: e.target.value as any }))}
          className="block w-full mt-1 rounded-md border-gray-300 shadow-sm"
        >
          <option value="solid">Solid</option>
          <option value="dashed">Dashed</option>
          <option value="dotted">Dotted</option>
        </select>

        <input
          type="color"
          value={style.borderColor}
          onChange={(e) => dispatch(updateStyle({ borderColor: e.target.value }))}
          className="block w-full mt-1"
        />

        <input
          type="range"
          min="1"
          max="10"
          value={style.borderWidth}
          onChange={(e) => dispatch(updateStyle({ borderWidth: parseInt(e.target.value) }))}
          className="block w-full mt-1"
        />
      </div>
    </ControlSection>
  );
};