import React from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Palette } from 'lucide-react';
import { updateStyle } from '../../store/mapSlice';
import type { RootState } from '../../store';
import { ControlSection } from './ControlSection';

export const BackgroundControls: React.FC = () => {
  const dispatch = useDispatch();
  const style = useSelector((state: RootState) => state.map.style);

  return (
    <ControlSection title="Background" icon={<Palette className="w-4 h-4" />}>
      <div className="space-y-2">
        <label className="block text-sm font-medium">
          Color
          <input
            type="color"
            value={style.backgroundColor}
            onChange={(e) => dispatch(updateStyle({ backgroundColor: e.target.value }))}
            className="block w-full mt-1"
          />
        </label>
        
        <label className="block text-sm font-medium">
          Opacity
          <input
            type="range"
            min="0"
            max="1"
            step="0.1"
            value={style.backgroundOpacity}
            onChange={(e) => dispatch(updateStyle({ backgroundOpacity: parseFloat(e.target.value) }))}
            className="block w-full mt-1"
          />
        </label>
      </div>
    </ControlSection>
  );
};