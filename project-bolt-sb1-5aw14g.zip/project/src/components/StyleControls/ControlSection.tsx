import React, { ReactNode } from 'react';

interface ControlSectionProps {
  title: string;
  icon: ReactNode;
  children: ReactNode;
}

export const ControlSection: React.FC<ControlSectionProps> = ({ title, icon, children }) => {
  return (
    <div className="space-y-2">
      <div className="flex items-center gap-2">
        {icon}
        <span className="text-sm font-medium">{title}</span>
      </div>
      {children}
    </div>
  );
};