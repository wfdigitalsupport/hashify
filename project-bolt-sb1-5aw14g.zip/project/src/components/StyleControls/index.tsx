import React from 'react';
import { Settings } from 'lucide-react';
import { BackgroundControls } from './BackgroundControls';
import { BorderControls } from './BorderControls';
import { PatternControls } from './PatternControls';

const StyleControls: React.FC = () => {
  return (
    <div className="p-4 bg-white rounded-lg shadow-lg">
      <div className="flex items-center gap-2 mb-4">
        <Settings className="w-5 h-5" />
        <h2 className="text-lg font-semibold">Style Controls</h2>
      </div>

      <div className="space-y-6">
        <BackgroundControls />
        <BorderControls />
        <PatternControls />
      </div>
    </div>
  );
};

export default StyleControls;