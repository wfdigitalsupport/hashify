import React from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { X } from 'lucide-react';
import { updateRegion, removeRegion } from '../../store/mapSlice';
import type { RootState } from '../../store';

const RegionSelector: React.FC = () => {
  const dispatch = useDispatch();
  const { regions } = useSelector((state: RootState) => state.map);

  return (
    <div className="space-y-2">
      <h3 className="text-sm font-medium text-gray-700">Selected Regions</h3>
      <div className="space-y-2">
        {Object.entries(regions).map(([key, region]) => (
          <div key={key} className="flex items-center gap-2 p-2 bg-gray-50 rounded">
            <input
              type="color"
              value={region.color}
              onChange={(e) => dispatch(updateRegion({ key, color: e.target.value }))}
              className="w-6 h-6 p-0 border-0 rounded cursor-pointer"
              title="Change region color"
            />
            <input
              type="text"
              value={region.label}
              onChange={(e) => dispatch(updateRegion({ key, label: e.target.value }))}
              className="flex-1 px-2 py-1 text-sm border rounded"
              placeholder="Region name"
            />
            <button
              onClick={() => dispatch(removeRegion(key))}
              className="p-1 hover:bg-gray-200 rounded"
              title="Remove region"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        ))}
        {Object.keys(regions).length === 0 && (
          <p className="text-sm text-gray-500 italic">
            Click on states to create regions
          </p>
        )}
      </div>
    </div>
  );
};

export default RegionSelector;