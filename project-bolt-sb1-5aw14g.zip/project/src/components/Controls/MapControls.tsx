import React from 'react';
import RegionSelector from './RegionSelector';
import StyleControls from './StyleControls';

const MapControls: React.FC = () => {
  return (
    <div className="absolute top-4 left-4 w-80 bg-white rounded-lg shadow-lg overflow-hidden z-10">
      <div className="p-4 space-y-4">
        <div className="space-y-2">
          <h2 className="text-sm font-medium text-gray-700">Step 1</h2>
          <p className="text-sm text-gray-600">
            Select the state you want and click on a state on the map. Right-click to remove.
          </p>
        </div>
        <RegionSelector />
        <StyleControls />
      </div>
    </div>
  );
};

export default MapControls;