import React from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Settings } from 'lucide-react';
import { updateStyle } from '../../store/mapSlice';
import type { RootState } from '../../store';

const StyleControls: React.FC = () => {
  const dispatch = useDispatch();
  const { style } = useSelector((state: RootState) => state.map);

  return (
    <div className="bg-white p-4 rounded-lg shadow-lg">
      <div className="flex items-center gap-2 mb-4">
        <Settings className="w-5 h-5" />
        <h2 className="text-lg font-semibold">Style Controls</h2>
      </div>

      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium mb-1">
            Background
          </label>
          <input
            type="checkbox"
            checked={style.showBackground}
            onChange={(e) => dispatch(updateStyle({ showBackground: e.target.checked }))}
            className="mr-2"
          />
        </div>

        <div>
          <label className="block text-sm font-medium mb-1">
            Border Color
          </label>
          <input
            type="color"
            value={style.borderColor}
            onChange={(e) => dispatch(updateStyle({ borderColor: e.target.value }))}
            className="w-full"
          />
        </div>

        <div>
          <label className="block text-sm font-medium mb-1">
            Show State Labels
          </label>
          <input
            type="checkbox"
            checked={style.showLabels}
            onChange={(e) => dispatch(updateStyle({ showLabels: e.target.checked }))}
            className="mr-2"
          />
        </div>
      </div>
    </div>
  );
};

export default StyleControls;