import React from 'react';
import { Map as MapIcon } from 'lucide-react';

const Header: React.FC = () => {
  return (
    <header className="bg-white shadow-sm z-10">
      <div className="px-4 py-2">
        <div className="flex items-center gap-2">
          <MapIcon className="w-6 h-6 text-blue-600" />
          <h1 className="text-xl font-bold text-gray-900">MapLet</h1>
        </div>
      </div>
    </header>
  );
};

export default Header;