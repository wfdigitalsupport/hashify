import React from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Settings, Image } from 'lucide-react';
import { updateStyle } from '../store/mapSlice';
import type { RootState } from '../store';

const StyleControls: React.FC = () => {
  const dispatch = useDispatch();
  const style = useSelector((state: RootState) => state.map.style);

  return (
    <div className="p-4 bg-white rounded-lg shadow-lg">
      <div className="flex items-center gap-2 mb-4">
        <Settings className="w-5 h-5" />
        <h2 className="text-lg font-semibold">Style Controls</h2>
      </div>

      <div className="space-y-4">
        <div className="space-y-2">
          <label className="block text-sm font-medium">
            Background Color
            <input
              type="color"
              value={style.backgroundColor}
              onChange={(e) =>
                dispatch(updateStyle({ backgroundColor: e.target.value }))
              }
              className="block w-full mt-1"
            />
          </label>

          <label className="block text-sm font-medium">
            Background Opacity
            <input
              type="range"
              min="0"
              max="1"
              step="0.1"
              value={style.backgroundOpacity}
              onChange={(e) =>
                dispatch(
                  updateStyle({ backgroundOpacity: parseFloat(e.target.value) })
                )
              }
              className="block w-full mt-1"
            />
          </label>
        </div>

        <div className="space-y-2">
          <select
            value={style.borderStyle}
            onChange={(e) =>
              dispatch(updateStyle({ borderStyle: e.target.value as any }))
            }
            className="block w-full mt-1 rounded-md border-gray-300 shadow-sm"
          >
            <option value="solid">Solid</option>
            <option value="dashed">Dashed</option>
            <option value="dotted">Dotted</option>
          </select>

          <input
            type="color"
            value={style.borderColor}
            onChange={(e) =>
              dispatch(updateStyle({ borderColor: e.target.value }))
            }
            className="block w-full mt-1"
          />

          <input
            type="range"
            min="1"
            max="10"
            value={style.borderWidth}
            onChange={(e) =>
              dispatch(updateStyle({ borderWidth: parseInt(e.target.value) }))
            }
            className="block w-full mt-1"
          />
        </div>

        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <Image className="w-4 h-4" />
            <span className="text-sm font-medium">Pattern Overlay</span>
          </div>

          <select
            value={style.pattern}
            onChange={(e) => dispatch(updateStyle({ pattern: e.target.value }))}
            className="block w-full mt-1 rounded-md border-gray-300 shadow-sm"
          >
            <option value="">None</option>
            <option value="dots">Dots</option>
            <option value="lines">Lines</option>
            <option value="grid">Grid</option>
          </select>

          {style.pattern && (
            <input
              type="range"
              min="0"
              max="1"
              step="0.1"
              value={style.patternOpacity || 0.5}
              onChange={(e) =>
                dispatch(
                  updateStyle({ patternOpacity: parseFloat(e.target.value) })
                )
              }
              className="block w-full mt-1"
            />
          )}
        </div>
      </div>
    </div>
  );
};

export default StyleControls;
