import React from 'react';
import { Provider } from 'react-redux';
import { store } from './store';
import MapContainer from './components/Map/MapContainer';
import MapControls from './components/Controls/MapControls';
import Header from './components/Layout/Header';

function App() {
  return (
    <Provider store={store}>
      <div className="h-screen flex flex-col">
        <Header />
        <main className="flex-1 relative">
          <MapContainer />
          <MapControls />
        </main>
      </div>
    </Provider>
  );
}

export default App;