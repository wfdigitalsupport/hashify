export function generateRandomColor(): string {
  const hue = Math.floor(Math.random() * 360);
  const saturation = 70 + Math.random() * 10; // 70-80%
  const lightness = 65 + Math.random() * 10; // 65-75%
  return `hsl(${hue}, ${saturation}%, ${lightness}%)`;
}