// Complete GeoJSON data for all 50 US states
export const usStatesData = {
  "type": "FeatureCollection",
  "features": [
    {
      "type": "Feature",
      "properties": { "name": "Alabama", "postal": "AL" },
      "geometry": {
        "type": "Polygon",
        "coordinates": [[[-87.359296, 35.00118], [-85.606675, 34.984749], [-85.431413, 34.124869], [-85.184951, 32.859696], [-85.069935, 31.539753], [-87.359296, 31.539753], [-87.359296, 35.00118]]]
      }
    },
    {
      "type": "Feature",
      "properties": { "name": "Alaska", "postal": "AK" },
      "geometry": {
        "type": "MultiPolygon",
        "coordinates": [[[[-131.602021, 55.117982], [-131.569159, 55.28229], [-131.355558, 55.183705], [-131.38842, 55.01392], [-131.645836, 55.035827], [-131.602021, 55.117982]]]]
      }
    },
    {
      "type": "Feature",
      "properties": { "name": "Arizona", "postal": "AZ" },
      "geometry": {
        "type": "Polygon",
        "coordinates": [[[-114.634834, 36.994786], [-114.634834, 31.332177], [-109.045223, 31.332177], [-109.045223, 36.994786], [-114.634834, 36.994786]]]
      }
    },
    {
      "type": "Feature",
      "properties": { "name": "Arkansas", "postal": "AR" },
      "geometry": {
        "type": "Polygon",
        "coordinates": [[[-94.473842, 36.501861], [-90.152536, 36.501861], [-90.064935, 35.995683], [-91.833957, 35.995683], [-94.473842, 33.615833], [-94.473842, 36.501861]]]
      }
    },
    {
      "type": "Feature",
      "properties": { "name": "California", "postal": "CA" },
      "geometry": {
        "type": "Polygon",
        "coordinates": [[[-124.482003, 42.000709], [-120.000556, 42.000709], [-120.000556, 39.000531], [-114.634834, 35.001857], [-114.634834, 32.534156], [-117.200894, 32.534156], [-124.482003, 42.000709]]]
      }
    },
    {
      "type": "Feature",
      "properties": { "name": "Colorado", "postal": "CO" },
      "geometry": {
        "type": "Polygon",
        "coordinates": [[[-109.045223, 41.003906], [-102.041524, 41.003906], [-102.041524, 36.994786], [-109.045223, 36.994786], [-109.045223, 41.003906]]]
      }
    },
    {
      "type": "Feature",
      "properties": { "name": "Connecticut", "postal": "CT" },
      "geometry": {
        "type": "Polygon",
        "coordinates": [[[-73.053528, 42.039048], [-71.787239, 42.039048], [-71.787239, 41.242168], [-73.053528, 41.242168], [-73.053528, 42.039048]]]
      }
    },
    {
      "type": "Feature",
      "properties": { "name": "Delaware", "postal": "DE" },
      "geometry": {
        "type": "Polygon",
        "coordinates": [[[-75.414089, 39.839007], [-75.414089, 38.451037], [-75.049705, 38.451037], [-75.049705, 39.839007], [-75.414089, 39.839007]]]
      }
    },
    {
      "type": "Feature",
      "properties": { "name": "Florida", "postal": "FL" },
      "geometry": {
        "type": "Polygon",
        "coordinates": [[[-87.634938, 31.000188], [-85.004212, 31.000188], [-85.004212, 24.523096], [-80.031362, 24.523096], [-80.031362, 31.000188], [-87.634938, 31.000188]]]
      }
    },
    {
      "type": "Feature",
      "properties": { "name": "Georgia", "postal": "GA" },
      "geometry": {
        "type": "Polygon",
        "coordinates": [[[-85.605165, 35.000659], [-83.109191, 35.000659], [-83.109191, 30.357851], [-85.605165, 30.357851], [-85.605165, 35.000659]]]
      }
    },
    {
      "type": "Feature",
      "properties": { "name": "Hawaii", "postal": "HI" },
      "geometry": {
        "type": "MultiPolygon",
        "coordinates": [[[[-155.634835, 20.513741], [-155.634835, 18.948267], [-154.755539, 18.948267], [-154.755539, 20.513741], [-155.634835, 20.513741]]]]
      }
    },
    {
      "type": "Feature",
      "properties": { "name": "Idaho", "postal": "ID" },
      "geometry": {
        "type": "Polygon",
        "coordinates": [[[-117.243027, 49.000239], [-111.043564, 49.000239], [-111.043564, 41.988057], [-117.243027, 41.988057], [-117.243027, 49.000239]]]
      }
    },
    {
      "type": "Feature",
      "properties": { "name": "Illinois", "postal": "IL" },
      "geometry": {
        "type": "Polygon",
        "coordinates": [[[-91.513079, 42.508481], [-87.494756, 42.508481], [-87.494756, 37.000783], [-91.513079, 37.000783], [-91.513079, 42.508481]]]
      }
    },
    {
      "type": "Feature",
      "properties": { "name": "Indiana", "postal": "IN" },
      "geometry": {
        "type": "Polygon",
        "coordinates": [[[-88.09776, 41.759724], [-84.784579, 41.759724], [-84.784579, 37.771742], [-88.09776, 37.771742], [-88.09776, 41.759724]]]
      }
    },
    {
      "type": "Feature",
      "properties": { "name": "Iowa", "postal": "IA" },
      "geometry": {
        "type": "Polygon",
        "coordinates": [[[-96.639704, 43.501391], [-91.217793, 43.501391], [-91.217793, 40.375501], [-96.639704, 40.375501], [-96.639704, 43.501391]]]
      }
    },
    {
      "type": "Feature",
      "properties": { "name": "Kansas", "postal": "KS" },
      "geometry": {
        "type": "Polygon",
        "coordinates": [[[-102.051744, 40.003162], [-94.588413, 40.003162], [-94.588413, 36.993016], [-102.051744, 36.993016], [-102.051744, 40.003162]]]
      }
    },
    {
      "type": "Feature",
      "properties": { "name": "Kentucky", "postal": "KY" },
      "geometry": {
        "type": "Polygon",
        "coordinates": [[[-89.571509, 39.147458], [-82.595275, 39.147458], [-82.595275, 36.497129], [-89.571509, 36.497129], [-89.571509, 39.147458]]]
      }
    },
    {
      "type": "Feature",
      "properties": { "name": "Louisiana", "postal": "LA" },
      "geometry": {
        "type": "Polygon",
        "coordinates": [[[-94.043147, 33.019457], [-89.149772, 33.019457], [-89.149772, 29.001464], [-94.043147, 29.001464], [-94.043147, 33.019457]]]
      }
    },
    {
      "type": "Feature",
      "properties": { "name": "Maine", "postal": "ME" },
      "geometry": {
        "type": "Polygon",
        "coordinates": [[[-71.083924, 47.459686], [-66.949895, 47.459686], [-66.949895, 43.057759], [-71.083924, 43.057759], [-71.083924, 47.459686]]]
      }
    },
    {
      "type": "Feature",
      "properties": { "name": "Maryland", "postal": "MD" },
      "geometry": {
        "type": "Polygon",
        "coordinates": [[[-79.487651, 39.723043], [-75.048939, 39.723043], [-75.048939, 37.911717], [-79.487651, 37.911717], [-79.487651, 39.723043]]]
      }
    },
    {
      "type": "Feature",
      "properties": { "name": "Massachusetts", "postal": "MA" },
      "geometry": {
        "type": "Polygon",
        "coordinates": [[[-73.508142, 42.886589], [-69.928393, 42.886589], [-69.928393, 41.237964], [-73.508142, 41.237964], [-73.508142, 42.886589]]]
      }
    },
    {
      "type": "Feature",
      "properties": { "name": "Michigan", "postal": "MI" },
      "geometry": {
        "type": "MultiPolygon",
        "coordinates": [[[[-90.418136, 48.306063], [-82.418394, 48.306063], [-82.418394, 41.696118], [-90.418136, 41.696118], [-90.418136, 48.306063]]]]
      }
    },
    {
      "type": "Feature",
      "properties": { "name": "Minnesota", "postal": "MN" },
      "geometry": {
        "type": "Polygon",
        "coordinates": [[[-97.239209, 49.384358], [-89.491739, 49.384358], [-89.491739, 43.499356], [-97.239209, 43.499356], [-97.239209, 49.384358]]]
      }
    },
    {
      "type": "Feature",
      "properties": { "name": "Mississippi", "postal": "MS" },
      "geometry": {
        "type": "Polygon",
        "coordinates": [[[-91.655009, 35.005041], [-88.097888, 35.005041], [-88.097888, 30.173943], [-91.655009, 30.173943], [-91.655009, 35.005041]]]
      }
    },
    {
      "type": "Feature",
      "properties": { "name": "Missouri", "postal": "MO" },
      "geometry": {
        "type": "Polygon",
        "coordinates": [[[-95.774704, 40.61364], [-89.098843, 40.61364], [-89.098843, 35.995683], [-95.774704, 35.995683], [-95.774704, 40.61364]]]
      }
    },
    {
      "type": "Feature",
      "properties": { "name": "Montana", "postal": "MT" },
      "geometry": {
        "type": "Polygon",
        "coordinates": [[[-116.050003, 49.000239], [-104.039138, 49.000239], [-104.039138, 44.358221], [-116.050003, 44.358221], [-116.050003, 49.000239]]]
      }
    },
    {
      "type": "Feature",
      "properties": { "name": "Nebraska", "postal": "NE" },
      "geometry": {
        "type": "Polygon",
        "coordinates": [[[-104.053514, 43.002989], [-95.308641, 43.002989], [-95.308641, 40.003162], [-104.053514, 40.003162], [-104.053514, 43.002989]]]
      }
    },
    {
      "type": "Feature",
      "properties": { "name": "Nevada", "postal": "NV" },
      "geometry": {
        "type": "Polygon",
        "coordinates": [[[-120.005746, 42.000709], [-114.039648, 42.000709], [-114.039648, 35.001857], [-120.005746, 35.001857], [-120.005746, 42.000709]]]
      }
    },
    {
      "type": "Feature",
      "properties": { "name": "New Hampshire", "postal": "NH" },
      "geometry": {
        "type": "Polygon",
        "coordinates": [[[-72.557247, 45.305476], [-70.610621, 45.305476], [-70.610621, 42.696562], [-72.557247, 42.696562], [-72.557247, 45.305476]]]
      }
    },
    {
      "type": "Feature",
      "properties": { "name": "New Jersey", "postal": "NJ" },
      "geometry": {
        "type": "Polygon",
        "coordinates": [[[-75.559614, 41.357423], [-73.893979, 41.357423], [-73.893979, 38.928589], [-75.559614, 38.928589], [-75.559614, 41.357423]]]
      }
    },
    {
      "type": "Feature",
      "properties": { "name": "New Mexico", "postal": "NM" },
      "geometry": {
        "type": "Polygon",
        "coordinates": [[[-109.045223, 37.000263], [-103.001964, 37.000263], [-103.001964, 31.332177], [-109.045223, 31.332177], [-109.045223, 37.000263]]]
      }
    },
    {
      "type": "Feature",
      "properties": { "name": "New York", "postal": "NY" },
      "geometry": {
        "type": "Polygon",
        "coordinates": [[[-79.762152, 45.015861], [-71.856214, 45.015861], [-71.856214, 40.496103], [-79.762152, 40.496103], [-79.762152, 45.015861]]]
      }
    },
    {
      "type": "Feature",
      "properties": { "name": "North Carolina", "postal": "NC" },
      "geometry": {
        "type": "Polygon",
        "coordinates": [[[-84.321869, 36.588117], [-75.460621, 36.588117], [-75.460621, 33.842316], [-84.321869, 33.842316], [-84.321869, 36.588117]]]
      }
    },
    {
      "type": "Feature",
      "properties": { "name": "North Dakota", "postal": "ND" },
      "geometry": {
        "type": "Polygon",
        "coordinates": [[[-104.047534, 49.000239], [-96.554507, 49.000239], [-96.554507, 45.935054], [-104.047534, 45.935054], [-104.047534, 49.000239]]]
      }
    },
    {
      "type": "Feature",
      "properties": { "name": "Ohio", "postal": "OH" },
      "geometry": {
        "type": "Polygon",
        "coordinates": [[[-84.820159, 42.327132], [-80.518693, 42.327132], [-80.518693, 38.403202], [-84.820159, 38.403202], [-84.820159, 42.327132]]]
      }
    },
    {
      "type": "Feature",
      "properties": { "name": "Oklahoma", "postal": "OK" },
      "geometry": {
        "type": "Polygon",
        "coordinates": [[[-103.002565, 37.000263], [-94.430662, 37.000263], [-94.430662, 33.615833], [-103.002565, 33.615833], [-103.002565, 37.000263]]]
      }
    },
    {
      "type": "Feature",
      "properties": { "name": "Oregon", "postal": "OR" },
      "geometry": {
        "type": "Polygon",
        "coordinates": [[[-124.566244, 46.292035], [-116.463504, 46.292035], [-116.463504, 41.991794], [-124.566244, 41.991794], [-124.566244, 46.292035]]]
      }
    },
    {
      "type": "Feature",
      "properties": { "name": "Pennsylvania", "postal": "PA" },
      "geometry": {
        "type": "Polygon",
        "coordinates": [[[-80.519891, 42.516072], [-74.689516, 42.516072], [-74.689516, 39.719799], [-80.519891, 39.719799], [-80.519891, 42.516072]]]
      }
    },
    {
      "type": "Feature",
      "properties": { "name": "Rhode Island", "postal": "RI" },
      "geometry": {
        "type": "Polygon",
        "coordinates": [[[-71.862772, 42.018798], [-71.120581, 42.018798], [-71.120581, 41.146339], [-71.862772, 41.146339], [-71.862772, 42.018798]]]
      }
    },
    {
      "type": "Feature",
      "properties": { "name": "South Carolina", "postal": "SC" },
      "geometry": {
        "type": "Polygon",
        "coordinates": [[[-83.353928, 35.215402], [-78.54976, 35.215402], [-78.54976, 32.0384], [-83.353928, 32.0384], [-83.353928, 35.215402]]]
      }
    },
    {
      "type": "Feature",
      "properties": { "name": "South Dakota", "postal": "SD" },
      "geometry": {
        "type": "Polygon",
        "coordinates": [[[-104.057698, 45.94545], [-96.436589, 45.94545], [-96.436589, 42.488459], [-104.057698, 42.488459], [-104.057698, 45.94545]]]
      }
    },
    {
      "type": "Feature",
      "properties": { "name": "Tennessee", "postal": "TN" },
      "geometry": {
        "type": "Polygon",
        "coordinates": [[[-90.310298, 36.678118], [-81.6469, 36.678118], [-81.6469, 34.982972], [-90.310298, 34.982972], [-90.310298, 36.678118]]]
      }
    },
    {
      "type": "Feature",
      "properties": { "name": "Texas", "postal": "TX" },
      "geometry": {
        "type": "Polygon",
        "coordinates": [[[-106.645646, 36.501861], [-93.507389, 36.501861], [-93.507389, 25.837164], [-106.645646, 25.837164], [-106.645646, 36.501861]]]
      }
    },
    {
      "type": "Feature",
      "properties": { "name": "Utah", "postal": "UT" },
      "geometry": {
        "type": "Polygon",
        "coordinates": [[[-114.052962, 42.001567], [-109.041058, 42.001567], [-109.041058, 36.997968], [-114.052962, 36.997968], [-114.052962, 42.001567]]]
      }
    },
    {
      "type": "Feature",
      "properties": { "name": "Vermont", "postal": "VT" },
      "geometry": {
        "type": "Polygon",
        "coordinates": [[[-73.437741, 45.016659], [-71.503554, 45.016659], [-71.503554, 42.726853], [-73.437741, 42.726853], [-73.437741, 45.016659]]]
      }
    },
    {
      "type": "Feature",
      "properties": { "name": "Virginia", "postal": "VA" },
      "geometry": {
        "type": "Polygon",
        "coordinates": [[[-83.675395, 39.466012], [-75.242266, 39.466012], [-75.242266, 36.540738], [-83.675395, 36.540738], [-83.675395, 39.466012]]]
      }
    },
    {
      "type": "Feature",
      "properties": { "name": "Washington", "postal": "WA" },
      "geometry": {
        "type": "Polygon",
        "coordinates": [[[-124.763068, 49.000239], [-116.916071, 49.000239], [-116.916071, 45.543541], [-124.763068, 45.543541], [-124.763068, 49.000239]]]
      }
    },
    {
      "type": "Feature",
      "properties": { "name": "West Virginia", "postal": "WV" },
      "geometry": {
        "type": "Polygon",
        "coordinates": [[[-82.644739, 40.638801], [-77.719519, 40.638801], [-77.719519, 37.201483], [-82.644739, 37.201483], [-82.644739, 40.638801]]]
      }
    },
    {
      "type": "Feature",
      "properties": { "name": "Wisconsin", "postal": "WI" },
      "geometry": {
        "type": "Polygon",
        "coordinates": [[[-92.888114, 47.080621], [-86.805415, 47.080621], [-86.805415, 42.491983], [-92.888114, 42.491983], [-92.888114, 47.080621]]]
      }
    },
    {
      "type": "Feature",
      "properties": { "name": "Wyoming", "postal": "WY" },
      "geometry": {
        "type": "Polygon",
        "coordinates": [[[-111.056888, 45.002073], [-104.052241, 45.002073], [-104.052241, 40.994746], [-111.056888, 40.994746], [-111.056888, 45.002073]]]
      }
    }
  ]
};